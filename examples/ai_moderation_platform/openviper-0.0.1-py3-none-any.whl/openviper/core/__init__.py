"""OpenViper core package."""
