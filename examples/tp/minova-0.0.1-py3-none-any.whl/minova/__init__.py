"""
MiNova - A production-ready, high-performance Python web framework, with modern async capabilities.
"""

from minova.app import MiNova
from minova.exceptions import (
    HTTPException,
    MiNovaException,
    NotFound,
    PermissionDenied,
    ValidationError,
)
from minova.http.request import Request
from minova.http.response import (
    FileResponse,
    HTMLResponse,
    JSONResponse,
    RedirectResponse,
    Response,
    StreamingResponse,
)
from minova.routing.router import Router, include


def setup(force: bool = False) -> None:
    """Initialize Minova settings and registry explicitly.

    This function should be called before importing any other Minova
    components that rely on settings.
    """
    from minova.conf import settings

    settings._setup(force=force)


__version__ = "0.0.1"
__all__ = [
    "MiNova",
    "Request",
    "Response",
    "JSONResponse",
    "HTMLResponse",
    "RedirectResponse",
    "StreamingResponse",
    "FileResponse",
    "Router",
    "include",
    "MiNovaException",
    "HTTPException",
    "NotFound",
    "PermissionDenied",
    "ValidationError",
    "__version__",
    "setup",
]
