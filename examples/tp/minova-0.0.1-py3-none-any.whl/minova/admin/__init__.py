"""MiNova Admin Panel - Vue 3 style admin interface.

Provides a powerful, auto-generated administration interface for MiNova models
with a Vue 3 SPA frontend.

Example:
    .. code-block:: python

        from minova.admin import admin, ModelAdmin, register

        @register(Post)
        class PostAdmin(ModelAdmin):
            list_display = ["title", "author", "created_at"]
            list_filter = ["is_published", "author"]
            search_fields = ["title", "body"]

        # Or using decorator shorthand
        @admin.register(Post)
        class PostAdmin(ModelAdmin):
            list_display = ["title", "created_at"]
"""

from minova.admin.actions import ActionResult, action
from minova.admin.decorators import register
from minova.admin.options import ModelAdmin
from minova.admin.registry import AdminRegistry, admin
from minova.admin.site import get_admin_site

__all__ = [
    "admin",
    "AdminRegistry",
    "ModelAdmin",
    "register",
    "get_admin_site",
    "action",
    "ActionResult",
]
