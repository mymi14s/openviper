"""
Tests for MiNova Admin module
"""
