"""AI model provider base class and inference protocol."""

from __future__ import annotations

import abc
from collections.abc import AsyncIterator
from typing import Any


class AIProvider(abc.ABC):
    """Abstract base class for AI model providers.

    Implement this class to integrate a new AI backend with MiNova.

    Example:
        .. code-block:: python

            from minova.ai.base import AIProvider

            class MyProvider(AIProvider):
                async def complete(self, prompt: str, **kwargs) -> str:
                    # Call your model
                    return "Hello from MyProvider"
    """

    name: str = "base"

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config

    @abc.abstractmethod
    async def complete(self, prompt: str, **kwargs: Any) -> str:
        """Generate a text completion for the given prompt.

        Args:
            prompt: Input text.
            **kwargs: Provider-specific options (temperature, max_tokens, etc.).

        Returns:
            Generated text string.
        """

    async def stream_complete(self, prompt: str, **kwargs: Any) -> AsyncIterator[str]:
        """Stream completion tokens.

        Default implementation calls ``complete()`` and yields everything at once.
        Override for true streaming.
        """
        result = await self.complete(prompt, **kwargs)
        yield result

    async def embed(self, text: str, **kwargs: Any) -> list[float]:
        """Return an embedding vector for the given text.

        Not all providers support embeddings.

        Raises:
            NotImplementedError: Provider does not support embeddings.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support embeddings.")

    async def before_inference(
        self, prompt: str, kwargs: dict[str, Any]
    ) -> tuple[str, dict[str, Any]]:
        """Hook called before each inference. Override to transform input.

        Args:
            prompt: The input prompt.
            kwargs: Inference keyword arguments.

        Returns:
            (modified_prompt, modified_kwargs)
        """
        return prompt, kwargs

    async def after_inference(self, prompt: str, response: str) -> str:
        """Hook called after each inference. Override to transform output.

        Args:
            prompt: Original prompt.
            response: Generated response.

        Returns:
            Modified response.
        """
        return response
