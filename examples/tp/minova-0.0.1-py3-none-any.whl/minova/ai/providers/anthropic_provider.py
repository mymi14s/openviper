"""Anthropic Claude provider implementation."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from minova.ai.base import AIProvider


class AnthropicProvider(AIProvider):
    """Anthropic Claude provider.

    Config:
        api_key: Your Anthropic API key.
        model: Model name (e.g. "claude-3-5-sonnet-20241022").
        max_tokens: Maximum completion tokens.
    """

    name = "anthropic"

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                from anthropic import AsyncAnthropic

                self._client = AsyncAnthropic(api_key=self.config.get("api_key"))
            except ImportError as exc:
                raise ImportError("anthropic package required: pip install anthropic") from exc
        return self._client

    async def complete(self, prompt: str, **kwargs: Any) -> str:
        prompt, kwargs = await self.before_inference(prompt, kwargs)
        client = self._get_client()
        model = kwargs.pop("model", self.config.get("model", "claude-3-5-sonnet-20241022"))
        max_tokens = kwargs.pop("max_tokens", self.config.get("max_tokens", 1024))

        response = await client.messages.create(
            model=model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
            **kwargs,
        )
        result = response.content[0].text
        return await self.after_inference(prompt, result)

    async def stream_complete(self, prompt: str, **kwargs: Any) -> AsyncIterator[str]:
        prompt, kwargs = await self.before_inference(prompt, kwargs)
        client = self._get_client()
        model = kwargs.pop("model", self.config.get("model", "claude-3-5-sonnet-20241022"))
        max_tokens = kwargs.pop("max_tokens", self.config.get("max_tokens", 1024))

        async with client.messages.stream(
            model=model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
        ) as stream:
            async for text in stream.text_stream:
                yield text
