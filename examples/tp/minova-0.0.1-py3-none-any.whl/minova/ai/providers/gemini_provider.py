"""Google Gemini AI provider for MiNova.

Supports Gemini Pro, Ultra, Flash, and Vision models via the
``google-generativeai`` SDK.

Installation:
    pip install google-generativeai

Configuration:
    .. code-block:: python

        from minova.ai.registry import ai_registry
        from minova.ai.providers.gemini_provider import GeminiProvider

        ai_registry.register("gemini", GeminiProvider, config={
            "api_key": "YOUR_GEMINI_API_KEY",
            "model": "gemini-1.5-flash",
        })

Environment variable:
    ``GEMINI_API_KEY`` is read as a fallback when ``api_key`` is not in config.
"""

from __future__ import annotations

import os
from collections.abc import AsyncIterator
from typing import Any

from minova.ai.base import AIProvider

# ── Cost table (USD per 1 000 000 tokens) ────────────────────────────────────
# Source: https://ai.google.dev/pricing  (as of Feb 2026)
_COST_TABLE: dict[str, dict[str, float]] = {
    # model-name: {"input": $/1M, "output": $/1M}
    "gemini-2.0-pro-exp": {"input": 0.00, "output": 0.00},  # free preview
    "gemini-2.0-flash": {"input": 0.10, "output": 0.40},
    "gemini-2.0-flash-thinking": {"input": 0.00, "output": 0.00},  # free preview
    "gemini-1.5-pro": {"input": 3.50, "output": 10.50},
    "gemini-1.5-pro-latest": {"input": 3.50, "output": 10.50},
    "gemini-1.5-flash": {"input": 0.075, "output": 0.30},
    "gemini-1.5-flash-latest": {"input": 0.075, "output": 0.30},
    "gemini-1.5-flash-8b": {"input": 0.0375, "output": 0.15},
    "gemini-1.0-pro": {"input": 0.50, "output": 1.50},
    "gemini-pro": {"input": 0.50, "output": 1.50},
    "gemini-pro-vision": {"input": 0.50, "output": 1.50},
}

# Default tokens-per-char estimate used when the SDK is unavailable
_CHARS_PER_TOKEN = 4.0


class GeminiError(Exception):
    """Base exception for Gemini provider errors."""


class GeminiAuthError(GeminiError):
    """Raised when the API key is missing or invalid."""


class GeminiRateLimitError(GeminiError):
    """Raised when the Gemini API rate limit is exceeded."""


class GeminiProvider(AIProvider):
    """Google Gemini AI provider.

    Config keys:
        api_key (str): Google AI API key.  Falls back to ``GEMINI_API_KEY`` env var.
        model (str): Default model name.  Defaults to ``"gemini-1.5-flash"``.
        temperature (float): Sampling temperature 0–2.  Defaults to ``1.0``.
        max_output_tokens (int): Maximum tokens in the response.  Defaults to ``2048``.
        top_p (float | None): Nucleus-sampling probability.
        top_k (int | None): Top-k sampling.
        candidate_count (int): Number of candidate responses (default 1).

    Vision:
        Pass ``images`` as a list of dicts via ``**kwargs`` to ``complete()``::

            await provider.complete(
                "Describe this image",
                images=[{"mime_type": "image/jpeg", "data": b"<raw bytes>"}],
            )

        Or pass a ``PIL.Image.Image`` object directly in the ``images`` list.
    """

    name = "gemini"

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)
        self._api_key: str = config.get("api_key") or os.environ.get("GEMINI_API_KEY") or ""
        if not self._api_key:
            raise GeminiAuthError(
                "Gemini API key is required. "
                "Pass api_key in config or set the GEMINI_API_KEY environment variable."
            )
        self._default_model: str = config.get("model", "gemini-1.5-flash")
        self._genai: Any = None  # lazily imported

    # ── SDK bootstrap ─────────────────────────────────────────────────────

    def _get_genai(self) -> Any:
        """Import and configure the google-generativeai SDK."""
        if self._genai is None:
            try:
                import google.generativeai as genai  # type: ignore[import-untyped]
            except ImportError as exc:
                raise ImportError(
                    "google-generativeai package is required for the Gemini provider. "
                    "Install it with: pip install google-generativeai"
                ) from exc
            genai.configure(api_key=self._api_key)
            self._genai = genai
        return self._genai

    def _make_model(self, model_name: str, **generation_config: Any) -> Any:
        """Instantiate a GenerativeModel with the given generation config."""
        genai = self._get_genai()
        cfg = {
            "temperature": self.config.get("temperature", 1.0),
            "max_output_tokens": self.config.get("max_output_tokens", 2048),
            "candidate_count": self.config.get("candidate_count", 1),
        }
        if self.config.get("top_p") is not None:
            cfg["top_p"] = self.config["top_p"]
        if self.config.get("top_k") is not None:
            cfg["top_k"] = self.config["top_k"]
        cfg.update(generation_config)  # caller overrides
        return genai.GenerativeModel(
            model_name=model_name,
            generation_config=genai.GenerationConfig(**cfg),
        )

    # ── Helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _build_contents(
        prompt: str,
        images: list[dict[str, Any]] | None = None,
        *,
        _sdk: Any = None,
    ) -> list[Any]:
        """Build the contents list for the generate_content call.

        Args:
            prompt: Text prompt.
            images: Optional list of ``{"mime_type": ..., "data": bytes}`` dicts,
                    or PIL Image objects.
            _sdk: Pre-imported ``google.generativeai`` module (used in tests).

        Returns:
            A list accepted by ``GenerativeModel.generate_content()``.
        """
        parts: list[Any] = [prompt]
        if images:
            for img in images:
                if isinstance(img, dict) and "data" in img:
                    # Inline image blob
                    try:
                        if _sdk is None:
                            # type: ignore[import-untyped,no-redef]
                            import google.generativeai as _sdk

                        parts.append(
                            _sdk.protos.Blob(
                                mime_type=img.get("mime_type", "image/jpeg"),
                                data=img["data"],
                            )
                        )
                    except (ImportError, AttributeError):
                        # Fallback: pass dict directly (newer SDK may accept it)
                        parts.append(img)
                else:
                    parts.append(img)
        return parts

    @staticmethod
    def _wrap_error(exc: Exception) -> GeminiError:
        """Convert a google-generativeai exception to a GeminiError subclass."""
        msg = str(exc)
        if "API_KEY_INVALID" in msg or "401" in msg or "403" in msg:
            return GeminiAuthError(f"Gemini authentication failed: {msg}")
        if "429" in msg or "RESOURCE_EXHAUSTED" in msg or "quota" in msg.lower():
            return GeminiRateLimitError(f"Gemini rate limit exceeded: {msg}")
        return GeminiError(f"Gemini API error: {msg}")

    # ── Core interface ─────────────────────────────────────────────────────

    async def complete(self, prompt: str, **kwargs: Any) -> str:
        """Generate a text completion.

        Args:
            prompt: Input text.
            **kwargs:
                model (str): Override the default model.
                images (list): Inline images for vision requests.
                temperature (float): Sampling temperature.
                max_output_tokens (int): Max tokens in the response.
                top_p (float): Nucleus sampling.
                top_k (int): Top-k sampling.

        Returns:
            Generated text string.

        Raises:
            GeminiAuthError: Invalid or missing API key.
            GeminiRateLimitError: Rate limit exceeded.
            GeminiError: Any other API error.
        """
        prompt, kwargs = await self.before_inference(prompt, kwargs)
        model_name = kwargs.pop("model", self._default_model)
        images = kwargs.pop("images", None)

        # Pull generation-config overrides from kwargs
        gen_cfg: dict[str, Any] = {}
        for key in (
            "temperature",
            "max_output_tokens",
            "top_p",
            "top_k",
            "candidate_count",
        ):
            if key in kwargs:
                gen_cfg[key] = kwargs.pop(key)

        try:
            model = self._make_model(model_name, **gen_cfg)
            genai = self._get_genai()
            contents = self._build_contents(prompt, images, _sdk=genai)
            response = await model.generate_content_async(contents)
            result = response.text
        except Exception as exc:
            raise self._wrap_error(exc) from exc

        return await self.after_inference(prompt, result)

    async def stream_complete(self, prompt: str, **kwargs: Any) -> AsyncIterator[str]:
        """Stream completion tokens.

        Args:
            prompt: Input text.
            **kwargs: Same as :meth:`complete`.  ``images`` supported.

        Yields:
            Incremental text chunks.

        Raises:
            GeminiAuthError: Invalid or missing API key.
            GeminiRateLimitError: Rate limit exceeded.
            GeminiError: Any other API error.
        """
        prompt, kwargs = await self.before_inference(prompt, kwargs)
        model_name = kwargs.pop("model", self._default_model)
        images = kwargs.pop("images", None)

        gen_cfg: dict[str, Any] = {}
        for key in (
            "temperature",
            "max_output_tokens",
            "top_p",
            "top_k",
            "candidate_count",
        ):
            if key in kwargs:
                gen_cfg[key] = kwargs.pop(key)

        try:
            model = self._make_model(model_name, **gen_cfg)
            genai = self._get_genai()
            contents = self._build_contents(prompt, images, _sdk=genai)
            async for chunk in await model.generate_content_async(contents, stream=True):
                if chunk.text:
                    yield chunk.text
        except Exception as exc:
            raise self._wrap_error(exc) from exc

    async def embed(self, text: str, **kwargs: Any) -> list[float]:
        """Generate an embedding vector for *text*.

        Args:
            text: Input text to embed.
            **kwargs:
                model (str): Embedding model.  Defaults to
                    ``"models/text-embedding-004"``.
                task_type (str): One of ``"RETRIEVAL_DOCUMENT"``,
                    ``"RETRIEVAL_QUERY"``, ``"SEMANTIC_SIMILARITY"``, etc.

        Returns:
            List of floats (embedding vector).

        Raises:
            GeminiError: On API failure.
        """
        genai = self._get_genai()
        model = kwargs.get("model", self.config.get("embed_model", "models/text-embedding-004"))
        task_type = kwargs.get("task_type", "RETRIEVAL_DOCUMENT")
        try:
            result = await genai.embed_content_async(
                model=model,
                content=text,
                task_type=task_type,
            )
            return result["embedding"]
        except Exception as exc:
            raise self._wrap_error(exc) from exc

    # ── Token counting & cost estimation ──────────────────────────────────

    async def count_tokens(self, text: str, model: str | None = None) -> int:
        """Count tokens in *text* using the Gemini API.

        Falls back to a character-based estimate if the API call fails.

        Args:
            text: Text to count tokens in.
            model: Model to use for counting (defaults to configured model).

        Returns:
            Estimated token count.
        """
        model_name = model or self._default_model
        try:
            genai = self._get_genai()
            m = genai.GenerativeModel(model_name=model_name)
            result = await m.count_tokens_async(text)
            return result.total_tokens
        except Exception:
            # Fallback to character estimate
            return max(1, round(len(text) / _CHARS_PER_TOKEN))

    def estimate_cost(
        self,
        input_tokens: int,
        output_tokens: int,
        model: str | None = None,
    ) -> dict[str, float]:
        """Estimate API cost for a request.

        Args:
            input_tokens: Number of input tokens.
            output_tokens: Number of output tokens.
            model: Model name (defaults to configured model).

        Returns:
            Dict with keys ``"input_cost"``, ``"output_cost"``, ``"total_cost"``
            (all in USD).
        """
        model_name = model or self._default_model
        # Try exact match, then try stripping "-latest" suffix
        rates = _COST_TABLE.get(model_name) or _COST_TABLE.get(model_name.replace("-latest", ""))
        if rates is None:
            # Default to gemini-1.5-pro pricing for unknown models
            rates = _COST_TABLE["gemini-1.5-pro"]

        input_cost = (input_tokens / 1_000_000) * rates["input"]
        output_cost = (output_tokens / 1_000_000) * rates["output"]
        return {
            "input_cost": round(input_cost, 8),
            "output_cost": round(output_cost, 8),
            "total_cost": round(input_cost + output_cost, 8),
        }
