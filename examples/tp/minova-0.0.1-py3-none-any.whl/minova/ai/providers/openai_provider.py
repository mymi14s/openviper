"""OpenAI provider implementation."""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Any

from minova.ai.base import AIProvider


class OpenAIProvider(AIProvider):
    """OpenAI GPT provider.

    Config:
        api_key: Your OpenAI API key.
        model: Model name (e.g. "gpt-4o", "gpt-3.5-turbo").
        temperature: Sampling temperature.
        max_tokens: Maximum completion tokens.
    """

    name = "openai"

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                from openai import AsyncOpenAI

                self._client = AsyncOpenAI(api_key=self.config.get("api_key"))
            except ImportError as exc:
                raise ImportError("openai package required: pip install openai") from exc
        return self._client

    async def complete(self, prompt: str, **kwargs: Any) -> str:
        prompt, kwargs = await self.before_inference(prompt, kwargs)
        client = self._get_client()
        model = kwargs.pop("model", self.config.get("model", "gpt-4o-mini"))
        temperature = kwargs.pop("temperature", self.config.get("temperature", 0.7))
        max_tokens = kwargs.pop("max_tokens", self.config.get("max_tokens", 1024))

        response = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            max_tokens=max_tokens,
            **kwargs,
        )
        result = response.choices[0].message.content or ""
        return await self.after_inference(prompt, result)

    async def stream_complete(self, prompt: str, **kwargs: Any) -> AsyncIterator[str]:
        prompt, kwargs = await self.before_inference(prompt, kwargs)
        client = self._get_client()
        model = kwargs.pop("model", self.config.get("model", "gpt-4o-mini"))
        temperature = kwargs.pop("temperature", self.config.get("temperature", 0.7))

        stream = await client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            stream=True,
            **kwargs,
        )
        async for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta

    async def embed(self, text: str, **kwargs: Any) -> list[float]:
        client = self._get_client()
        model = kwargs.pop("model", self.config.get("embed_model", "text-embedding-ada-002"))
        response = await client.embeddings.create(input=text, model=model)
        return response.data[0].embedding
