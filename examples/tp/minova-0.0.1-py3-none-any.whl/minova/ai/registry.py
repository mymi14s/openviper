"""AI model registry — register and retrieve named providers.

Example:
    .. code-block:: python

        from minova.ai.registry import ai_registry
        from minova.ai.providers.openai_provider import OpenAIProvider

        ai_registry.register("gpt4", OpenAIProvider, config={
            "api_key": "sk-...",
            "model": "gpt-4",
        })

        model = ai_registry.get("gpt4")
        response = await model.complete("Summarise the blog post below...")
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

from minova.conf import settings

if TYPE_CHECKING:
    from minova.ai.base import AIProvider


class AIRegistry:
    """Central registry for AI providers.

    Providers are registered by name and instantiated lazily on first use.
    """

    def __init__(self) -> None:
        self._providers: dict[str, AIProvider] = {}
        self._provider_classes: dict[str, tuple[type[AIProvider], dict[str, Any]]] = {}

    def register(
        self,
        name: str,
        provider_class: type[AIProvider],
        config: dict[str, Any] | None = None,
    ) -> None:
        """Register a provider class under a name.

        Args:
            name: Unique model name, e.g. ``"gpt-4"`` or ``"my-local-llm"``.
            provider_class: Concrete AIProvider subclass.
            config: Provider configuration dict (api_key, model, etc.).
        """
        self._provider_classes[name] = (provider_class, config or {})

    def get(self, name: str) -> AIProvider:
        """Retrieve a provider instance by name, instantiating if needed.

        Args:
            name: Registered model name.

        Returns:
            AIProvider instance.

        Raises:
            KeyError: Name not registered.
        """
        if name not in self._providers:
            if name not in self._provider_classes:
                raise KeyError(
                    f"AI provider '{name}' not registered. "
                    f"Available: {list(self._provider_classes)}"
                )
            cls, cfg = self._provider_classes[name]
            self._providers[name] = cls(cfg)
        return self._providers[name]

    def list_providers(self) -> list[str]:
        """Return all registered provider names."""
        return list(self._provider_classes)

    def _load_from_settings(self) -> None:
        """Auto-register providers defined in settings.AI_MODELS."""
        try:
            for name, spec in getattr(settings, "AI_MODELS", {}).items():
                provider_type = spec.get("provider", "")
                cfg = {k: v for k, v in spec.items() if k != "provider"}
                cls = self._resolve_provider_class(provider_type)
                if cls:
                    self.register(name, cls, cfg)
        except Exception:
            pass

    @staticmethod
    def _resolve_provider_class(provider_type: str) -> type[AIProvider] | None:
        mapping = {
            "openai": "minova.ai.providers.openai_provider.OpenAIProvider",
            "anthropic": "minova.ai.providers.anthropic_provider.AnthropicProvider",
            "ollama": "minova.ai.providers.ollama_provider.OllamaProvider",
            "gemini": "minova.ai.providers.gemini_provider.GeminiProvider",
            "grok": "minova.ai.providers.grok_provider.GrokProvider",
        }
        path = mapping.get(provider_type)
        if not path:
            return None
        try:
            module_path, cls_name = path.rsplit(".", 1)
            mod = importlib.import_module(module_path)
            return getattr(mod, cls_name)
        except (ImportError, AttributeError):
            return None


# Global singleton
ai_registry = AIRegistry()
