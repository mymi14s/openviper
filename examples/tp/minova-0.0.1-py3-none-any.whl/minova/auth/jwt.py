"""JWT token creation and verification for MiNova.

Uses ``python-jose`` under the hood with HS256 algorithm (RS256 configurable).
"""

from __future__ import annotations

import datetime
from typing import Any

from jose import JWTError, jwt

from minova.conf import settings
from minova.exceptions import AuthenticationFailed, TokenExpired
from minova.utils import timezone


def _secret() -> str:
    return getattr(settings, "SECRET_KEY", "fallback-secret-key")


def _algorithm() -> str:
    return getattr(settings, "JWT_ALGORITHM", "HS256")


def _access_expire() -> datetime.timedelta:
    return getattr(settings, "JWT_ACCESS_TOKEN_EXPIRE", datetime.timedelta(hours=24))


def _refresh_expire() -> datetime.timedelta:
    return getattr(settings, "JWT_REFRESH_TOKEN_EXPIRE", datetime.timedelta(days=7))


def create_access_token(
    user_id: int | str,
    extra_claims: dict[str, Any] | None = None,
) -> str:
    now = timezone.now()
    expire = now + _access_expire()
    claims: dict[str, Any] = {
        "sub": str(user_id),
        "iat": now,
        "exp": expire,
        "type": "access",
    }
    if extra_claims:
        claims.update(extra_claims)
    return jwt.encode(claims, _secret(), algorithm=_algorithm())


def create_refresh_token(user_id: int | str) -> str:
    now = timezone.now()
    expire = now + _refresh_expire()
    claims: dict[str, Any] = {
        "sub": str(user_id),
        "iat": now,
        "exp": expire,
        "type": "refresh",
    }
    return jwt.encode(claims, _secret(), algorithm=_algorithm())


def decode_access_token(token: str) -> dict[str, Any]:
    """Decode and verify a JWT access token.

    Args:
        token: Encoded JWT string.

    Returns:
        Decoded claims dict.

    Raises:
        TokenExpired: Token has passed its expiry.
        AuthenticationFailed: Token is invalid or malformed.
    """
    try:
        payload = jwt.decode(token, _secret(), algorithms=[_algorithm()])
        if payload.get("type") != "access":
            raise AuthenticationFailed("Invalid token type.")
        return payload
    except JWTError as exc:
        if "expired" in str(exc).lower():
            raise TokenExpired() from exc
        raise AuthenticationFailed(f"Invalid token: {exc}") from exc


def decode_refresh_token(token: str) -> dict[str, Any]:
    """Decode and verify a JWT refresh token.

    Args:
        token: Encoded JWT string.

    Returns:
        Decoded claims dict.

    Raises:
        TokenExpired: Token has passed its expiry.
        AuthenticationFailed: Token is invalid or malformed.
    """
    try:
        payload = jwt.decode(token, _secret(), algorithms=[_algorithm()])
        if payload.get("type") != "refresh":
            raise AuthenticationFailed("Invalid token type.")
        return payload
    except JWTError as exc:
        if "expired" in str(exc).lower():
            raise TokenExpired() from exc
        raise AuthenticationFailed(f"Invalid token: {exc}") from exc
