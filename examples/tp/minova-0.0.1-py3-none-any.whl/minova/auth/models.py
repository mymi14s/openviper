"""MiNova built-in User, Role, and Permission models."""

from __future__ import annotations

from minova.auth.hashers import check_password, make_password
from minova.db.fields import (
    BooleanField,
    CharField,
    DateTimeField,
    EmailField,
    IntegerField,
    TextField,
)
from minova.db.models import Model


class Permission(Model):
    """A named permission grant.

    Example::

        >>> perm = await Permission.objects.create(codename="post.create", name="Can create posts")
    """

    codename = CharField(max_length=100, unique=True)
    name = CharField(max_length=255)
    content_type = CharField(max_length=100, null=True)  # "app.Model"
    created_at = DateTimeField(auto_now_add=True)

    class Meta:
        table_name = "auth_permissions"

    def __str__(self) -> str:
        return self.codename or ""


class Role(Model):
    """A named role that bundles a set of permissions.

    Roles can be hierarchical (parent_id for inheritance).

    Example:
        >>> admin = await Role.objects.create(name="admin")
    """

    _app_name = "auth"

    name = CharField(max_length=100, unique=True)
    description = TextField(null=True)
    parent_id = IntegerField(null=True)  # FK to self (hierarchy)
    created_at = DateTimeField(auto_now_add=True)

    class Meta:
        table_name = "auth_roles"

    def __str__(self) -> str:
        return self.name or ""


class UserRole(Model):
    """Junction table between User and Role."""

    _app_name = "auth"

    user_id = IntegerField()
    role_id = IntegerField()

    class Meta:
        table_name = "auth_user_roles"


class RolePermission(Model):
    """Junction table between Role and Permission."""

    _app_name = "auth"

    role_id = IntegerField()
    permission_id = IntegerField()

    class Meta:
        table_name = "auth_role_permissions"


class User(Model):
    """Built-in user model.

    Passwords are stored hashed via Argon2id (with bcrypt fallback).

    Attributes:
        username: Unique login identifier.
        email: Unique email address.
        password: Hashed password — never set this directly; use ``set_password()``.
        is_active: Soft-delete flag.
        is_superuser: Grant all permissions when True.
        is_staff: Allow access to the admin interface.
        created_at: Account creation timestamp.
        updated_at: Last modification timestamp.
        last_login: Last successful login timestamp.
    """

    _app_name = "auth"

    username = CharField(max_length=150, unique=True)
    email = EmailField(unique=True)
    password = CharField(max_length=255, null=True)  # Hashed
    first_name = CharField(max_length=150, null=True)
    last_name = CharField(max_length=150, null=True)
    is_active = BooleanField(default=True)
    is_superuser = BooleanField(default=False)
    is_staff = BooleanField(default=False)
    created_at = DateTimeField(auto_now_add=True)
    updated_at = DateTimeField(auto_now=True)
    last_login = DateTimeField(null=True)

    class Meta:
        table_name = "auth_users"

    # ── Password methods ──────────────────────────────────────────────────

    def set_password(self, raw_password: str) -> None:
        """Hash and store a password.

        Uses Argon2id by default, falls back to bcrypt.
        """

        self.password = make_password(raw_password)

    def check_password(self, raw_password: str) -> bool:
        """Verify raw_password against the stored hash."""

        if not self.password:
            return False
        return check_password(raw_password, self.password)

    # ── Permission checks ─────────────────────────────────────────────────

    @property
    def is_authenticated(self) -> bool:
        return True

    @property
    def is_anonymous(self) -> bool:
        return False

    async def get_roles(self) -> list[Role]:
        """Return all roles assigned to this user."""
        user_roles = await UserRole.objects.filter(user_id=self.pk).all()
        role_ids = [ur.role_id for ur in user_roles]
        if not role_ids:
            return []
        return await Role.objects.filter(id__in=role_ids).all()

    async def get_permissions(self) -> set[str]:
        """Return all permission codenames for this user (direct + via roles)."""
        if self.is_superuser:
            # Superusers have all permissions
            all_perms = await Permission.objects.all()
            return {p.codename for p in all_perms}

        roles = await self.get_roles()
        if not roles:
            return set()

        role_ids = [r.pk for r in roles]
        role_perms = await RolePermission.objects.filter(role_id__in=role_ids).all()
        perm_ids = [rp.permission_id for rp in role_perms]
        if not perm_ids:
            return set()

        perms = await Permission.objects.filter(id__in=perm_ids).all()
        return {p.codename for p in perms}

    async def has_perm(self, codename: str) -> bool:
        """Check if user has a specific permission by codename."""
        if self.is_superuser:
            return True
        perms = await self.get_permissions()
        return codename in perms

    async def has_role(self, role_name: str) -> bool:
        """Check if user is assigned to a specific role."""
        if self.is_superuser:
            return True
        roles = await self.get_roles()
        return any(r.name == role_name for r in roles)

    async def assign_role(self, role: Role) -> None:
        """Assign a role to this user."""
        existing = await UserRole.objects.filter(user_id=self.pk, role_id=role.pk).first()
        if not existing:
            await UserRole.objects.create(user_id=self.pk, role_id=role.pk)

    async def remove_role(self, role: Role) -> None:
        """Remove a role from this user."""
        await UserRole.objects.filter(user_id=self.pk, role_id=role.pk).delete()

    @property
    def full_name(self) -> str:
        parts = [self.first_name or "", self.last_name or ""]
        return " ".join(p for p in parts if p).strip()

    def __str__(self) -> str:
        return self.username or str(self.pk)

    def __repr__(self) -> str:
        return f"<User id={self.pk!r} username={self.username!r}>"


class AnonymousUser:
    """Sentinel object representing an unauthenticated visitor."""

    is_authenticated: bool = False
    is_anonymous: bool = True
    is_active: bool = False
    is_superuser: bool = False
    is_staff: bool = False
    pk = None
    id = None
    username = ""
    email = ""

    async def has_perm(self, codename: str) -> bool:
        return False

    async def has_role(self, role_name: str) -> bool:
        return False

    async def get_permissions(self) -> set[str]:
        return set()

    def __bool__(self) -> bool:
        return False

    def __repr__(self) -> str:
        return "AnonymousUser"
