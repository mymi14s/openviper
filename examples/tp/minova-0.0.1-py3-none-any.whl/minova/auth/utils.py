"""Authentication utilities for MiNova."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

from minova.conf import settings

if TYPE_CHECKING:
    from minova.db.models import Model


def get_user_model() -> type[Model]:
    """Return the User model as specified by USER_MODEL setting.
    This allows projects to use a custom User model by setting USER_MODEL
        in their project settings to a dotted path like 'myapp.models.User'.

        Returns:
            The User model class configured in settings.

        Raises:
            ImportError: If the specified module cannot be imported.
            AttributeError: If the model class is not found in the module.
    """

    user_model_path = getattr(settings, "USER_MODEL", "minova.auth.models.User")

    # Parse the dotted path
    module_path, class_name = user_model_path.rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)
