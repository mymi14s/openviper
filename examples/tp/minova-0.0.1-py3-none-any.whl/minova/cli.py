"""MiNova CLI — global ``minova`` command.

Provides project scaffolding commands separate from the per-project
``manage.py`` interface.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import click

try:
    from rich.console import Console
    from rich.panel import Panel

    _console = Console()
    _has_rich = True
except ImportError:
    _console = None  # type: ignore[assignment]
    _has_rich = False

import minova
from minova.conf.settings import generate_secret_key


def _print(msg: str, style: str = "") -> None:
    if _has_rich and _console:
        _console.print(msg, style=style or None)
    else:
        print(msg)


@click.group()
@click.version_option(package_name="minova", prog_name="minova")
def cli() -> None:
    """MiNova web framework CLI."""


# ---------------------------------------------------------------------------
# create-project
# ---------------------------------------------------------------------------

_MANAGE_PY_TEMPLATE = '''\
#!/usr/bin/env python
"""MiNova manage.py for {project_name}."""

import os
import sys
import minova
from minova.core.management import execute_from_command_line

def main() -> None:
    os.environ.setdefault("MINOVA_SETTINGS_MODULE", "{project_name}.settings")
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    minova.setup(force=True)    
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
'''

_SETTINGS_TEMPLATE = '''\
"""Settings for {project_name}."""

import os
from minova.conf.settings import Settings


class ProjectSettings(Settings):
    PROJECT_NAME: str = "{project_name}"
    DEBUG: bool = bool(os.environ.get("DEBUG", "1"))
    DATABASE_URL: str = os.environ.get("DATABASE_URL", "sqlite+aiosqlite:///db.sqlite3")
    SECRET_KEY: str = os.environ.get("SECRET_KEY", "{secret_key}")
    INSTALLED_APPS: list = [
        "minova.auth",
    ]
    MIDDLEWARE: list = [
        "minova.middleware.security.SecurityMiddleware",
        "minova.middleware.cors.CORSMiddleware",
        "minova.middleware.auth.AuthenticationMiddleware",
        "minova.admin.middleware.AdminMiddleware",
    ]
    ALLOWED_HOSTS: list = ["*"]
    STATIC_ROOT: str = os.environ.get("STATIC_ROOT", "static")
    STATIC_URL: str = os.environ.get("STATIC_URL", "/static/")
    MEDIA_ROOT: str = os.environ.get("MEDIA_ROOT", "media")
    MEDIA_URL: str = os.environ.get("MEDIA_URL", "/media/")
'''

_ASGI_TEMPLATE = '''\

"""ASGI application for {project_name}."""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ.setdefault("MINOVA_SETTINGS_MODULE", "{project_name}.settings")


try:
    from .routes import route_paths
except ImportError:
    route_paths = []

# Create application
app = MiNova()

# Include routers
for prefix, router in route_paths:
    app.include_router(router, prefix=prefix)
'''

_ROUTES_TEMPLATE = '''\
"""Top-level routes for {project_name}."""

from minova.conf import settings
from minova.admin import get_admin_site
from minova.staticfiles import media, static

from {project_name}.views import router as root_router


route_paths = [
    ("/admin", get_admin_site()),
    ("/root", root_router)
]


# to force static files serving in production, not recommended
if not settings.DEBUG:
    route_paths += static() + media()
'''

_VIEWS_TEMPLATE = '''
"""Views for {project_name}."""

from minova.http.response import HTMLResponse, JSONResponse
from minova.routing import Router


async def home(request):
    """Home page view."""
    context = {{
        "title": "Welcome to {project_name}",
        "project_name": "{project_name}",
        "message": "Your MiNova project is running successfully."
    }}
    return HTMLResponse(template="home.html", context=context)


async def api_index(request):
    """API endpoint view that handles both GET and POST."""
    if request.method == "GET":
        return JSONResponse({{"message": "Welcome to {project_name} API!", "status": "success"}})
    elif request.method == "POST":
        return JSONResponse({{"message": "Data received", "status": "success", "method": "POST"}})
    else:
        return JSONResponse({{"error": "Method not allowed", "status": "error"}}, status_code=405)


# Routes for apps should be in each app's routes.py file
router = Router()

# Default routes for {project_name}
router.add("/home", home, namespace="home-view")
router.add("/api", api_index, namespace="api-view", methods=["GET", "POST"])
'''

_HOME_TEMPLATE_HTML = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ title }}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1 { color: #333; }
        ul { list-style-type: none; padding: 0; }
        li { margin: 10px 0; }
        a { color: #007bff; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <h1>Welcome to {{ project_name }}!</h1>
    <p>{{ message }}</p>
    <ul>
        <li><a href="/api">API Endpoint</a></li>
        <li><a href="/admin">Admin Panel</a></li>
    </ul>
</body>
</html>
"""

_PROJECT_INIT_TEMPLATE = '"""{project_name} project."""\n'


_GITIGNORE_TEMPLATE = """\
__pycache__/
*.py[cod]
*.egg-info/
.env
.venv/
venv/
db.sqlite3
*.log
.DS_Store
"""


@cli.command("create-project")
@click.argument("name")
@click.option("--directory", "-d", default=None, help="Parent directory (default: CWD)")
def create_project(name: str, directory: str | None) -> None:
    """Scaffold a new MiNova project called NAME."""
    if not name.isidentifier():
        click.echo(f"Error: '{name}' is not a valid Python identifier.", err=True)
        sys.exit(1)

    base = Path(directory) if directory else Path.cwd()
    project_root = base / name

    if project_root.exists():
        click.echo(f"Error: '{project_root}' already exists.", err=True)
        sys.exit(1)

    secret_key = generate_secret_key()
    ctx = {"project_name": name, "secret_key": secret_key}

    # Create directory structure
    (project_root / name).mkdir(parents=True)

    def write(path: Path, content: str) -> None:
        path.write_text(content.format(**ctx))

    write(project_root / "manage.py", _MANAGE_PY_TEMPLATE)
    os.chmod(project_root / "manage.py", 0o755)
    write(project_root / name / "__init__.py", _PROJECT_INIT_TEMPLATE)
    write(project_root / name / "settings.py", _SETTINGS_TEMPLATE)
    write(project_root / name / "asgi.py", _ASGI_TEMPLATE)
    write(project_root / name / "routes.py", _ROUTES_TEMPLATE)
    write(project_root / name / "views.py", _VIEWS_TEMPLATE)
    write(project_root / ".gitignore", _GITIGNORE_TEMPLATE)
    (project_root / "static").mkdir()
    (project_root / "templates").mkdir()
    (project_root / "templates" / "home.html").write_text(_HOME_TEMPLATE_HTML)
    (project_root / "tests").mkdir()
    (project_root / "tests" / "__init__.py").write_text("# Test package\n\n")

    if _has_rich:
        _console.print(
            Panel.fit(
                f"[bold green]Project '{name}' created![/bold green]\n\n"
                f"  [cyan]cd {name}[/cyan]\n"
                f"  [cyan]python manage.py runserver[/cyan]",
                title="MiNova",
            )
        )
    else:
        click.echo(f"Project '{name}' created at {project_root}")
        click.echo(f"  cd {name}")
        click.echo("  python manage.py runserver")


# ---------------------------------------------------------------------------
# create-app
# ---------------------------------------------------------------------------


@cli.command("create-app")
@click.argument("name")
@click.option("--directory", "-d", default=None, help="Target directory (default: CWD)")
def create_app(name: str, directory: str | None) -> None:
    """Scaffold a new app inside an existing MiNova project."""
    # Delegate to the management command so it works both ways

    args = [sys.executable, "manage.py", "create-app", name]
    if directory:
        args += ["--directory", directory]
    result = subprocess.run(args)
    sys.exit(result.returncode)


# ---------------------------------------------------------------------------
# version (standalone)
# ---------------------------------------------------------------------------


@cli.command("version")
def version_cmd() -> None:
    """Print MiNova version."""

    click.echo(f"MiNova {minova.__version__}")


if __name__ == "__main__":
    cli()
