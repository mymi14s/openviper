"""MiNova settings & configuration system.

Settings are defined as a class, loaded from
``MINOVA_SETTINGS_MODULE`` and overridable via environment variables
or ``.env`` files through python-dotenv.

Environment detection uses ``MINOVA_ENV`` (default: ``development``).

Example:
    .. code-block:: python

        # myproject/settings.py
        from minova.conf import Settings

        class MySettings(Settings):
            PROJECT_NAME = "MyBlog"
            DATABASE_URL = "sqlite:///db.sqlite3"
"""

from __future__ import annotations

import importlib
import os
import secrets
import sys
from datetime import timedelta
from typing import Any

from minova.exceptions import SettingsValidationError

try:
    from dotenv import load_dotenv as _load_dotenv

    _HAS_DOTENV = True
except ImportError:
    _HAS_DOTENV = False


# ── Base Settings ─────────────────────────────────────────────────────────────


class SettingsMeta(type):
    """Metaclass for individual Settings classes.

    Allows accessing settings as class attributes (e.g., ``Settings.DEBUG``)
    which will proxy to the active global settings instance.
    """

    _subclasses: list[type[Settings]] = []

    def __init__(cls, name: str, bases: tuple[type, ...], attrs: dict[str, Any]) -> None:
        super().__init__(name, bases, attrs)
        # Register subclasses as they are defined
        if name != "Settings":
            SettingsMeta._subclasses.append(cls)  # type: ignore[arg-type]

            # Proactively update the global settings instance if it was already
            # initialized with the base Settings class (default fallback) OR if
            # it hasn't been initialized yet.
            try:
                from minova.conf import settings as _active_settings

                # If the current instance is EXACTLY the base Settings OR None,
                # we immediately switch to this new project-specific class.
                current = _active_settings._instance
                if current is not None and type(current) is Settings:
                    _active_settings._instance = cls()
            except (ImportError, AttributeError):
                pass

    def __getattribute__(cls, name: str) -> Any:
        # We only intercept uppercase settings
        if not name.isupper():
            return super().__getattribute__(name)

        # Proxy to the active global settings
        try:
            from minova.conf import settings as _active_settings

            # Use getattr on the proxy instance
            return getattr(_active_settings, name)
        except (ImportError, AttributeError):
            # Fallback to class attribute if settings proxy isn't ready
            return super().__getattribute__(name)


class Settings(metaclass=SettingsMeta):
    """Base configuration class.  Override in your project's settings.py.

    All class-level attributes become settings accessible via
    ``from minova.conf import settings`` after initialization.
    """

    # ── Project ───────────────────────────────────────────────────────────
    PROJECT_NAME: str = "MiNova Application"
    VERSION: str = "0.0.1"
    DEBUG: bool = True
    ALLOWED_HOSTS: list[str] = ["localhost", "127.0.0.1"]
    ROOT_URLCONF: str = ""  # dotted path to main router module
    INSTALLED_APPS: list[str] = []
    USE_TZ: bool = True
    TIME_ZONE: str = "UTC"
    MIDDLEWARE: list[str] = [
        "minova.middleware.security.SecurityMiddleware",
        "minova.middleware.cors.CORSMiddleware",
        "minova.middleware.auth.AuthenticationMiddleware",
    ]

    # ── Admin Panel ───────────────────────────────────────────────────────
    ADMIN_TITLE: str = "MiNova Admin"
    ADMIN_HEADER_TITLE: str = "MiNova"
    ADMIN_FOOTER_TITLE: str = "MiNova Admin"

    # ── Secret Key ────────────────────────────────────────────────────────
    SECRET_KEY: str = "INSECURE-CHANGE-ME"

    # ── Database ──────────────────────────────────────────────────────────
    DATABASE_URL: str = ""
    DATABASE_ECHO: bool = False
    DATABASE_POOL_SIZE: int = 5
    DATABASE_MAX_OVERFLOW: int = 10
    DATABASE_POOL_RECYCLE: int = 3600

    # ── Cache ─────────────────────────────────────────────────────────────
    CACHE_BACKEND: str = "memory"  # "memory" | "redis"
    CACHE_URL: str = "redis://localhost:6379/0"
    CACHE_TTL: int = 300

    # ── Authentication ────────────────────────────────────────────────────
    PASSWORD_HASHERS: list[str] = ["argon2", "bcrypt"]
    SESSION_COOKIE_NAME: str = "sessionid"
    SESSION_TIMEOUT: timedelta = timedelta(hours=1)
    SESSION_COOKIE_SECURE: bool = False
    SESSION_COOKIE_HTTPONLY: bool = True
    SESSION_COOKIE_SAMESITE: str = "Lax"
    USER_MODEL: str = "minova.auth.models.User"

    # ── JWT ───────────────────────────────────────────────────────────────
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE: timedelta = timedelta(hours=24)
    JWT_REFRESH_TOKEN_EXPIRE: timedelta = timedelta(days=7)

    # ── CSRF ──────────────────────────────────────────────────────────────
    CSRF_COOKIE_NAME: str = "csrftoken"
    CSRF_COOKIE_SECURE: bool = False
    CSRF_COOKIE_HTTPONLY: bool = True
    CSRF_COOKIE_SAMESITE: str = "Lax"
    CSRF_TRUSTED_ORIGINS: list[str] = []

    # ── CORS ──────────────────────────────────────────────────────────────
    CORS_ALLOWED_ORIGINS: list[str] = ["http://localhost:3000", "http://127.0.0.1:3000"]
    CORS_ALLOW_CREDENTIALS: bool = True
    CORS_ALLOWED_METHODS: list[str] = [
        "GET",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "OPTIONS",
    ]
    CORS_ALLOWED_HEADERS: list[str] = ["*"]
    CORS_MAX_AGE: int = 600

    # ── Static Files ──────────────────────────────────────────────────────
    STATIC_URL: str = "/static/"
    STATIC_ROOT: str = "./static/"
    STATICFILES_DIRS: list[str] = ["static/"]
    MEDIA_URL: str = "/media/"
    MEDIA_ROOT: str = "./media/"

    # ── Templates ─────────────────────────────────────────────────────────
    TEMPLATES_DIR: str = "templates/"
    TEMPLATE_AUTO_RELOAD: bool = True

    # ── Logging ───────────────────────────────────────────────────────────
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "text"  # "text" | "json"

    # ── Email ─────────────────────────────────────────────────────────────
    EMAIL_BACKEND: str = "console"  # "console" | "smtp" | "memory"
    EMAIL_HOST: str = "localhost"
    EMAIL_PORT: int = 587
    EMAIL_USE_TLS: bool = True
    EMAIL_USER: str = ""
    EMAIL_PASSWORD: str = ""
    EMAIL_FROM: str = "noreply@example.com"

    # ── Security Headers ─────────────────────────────────────────────────
    SECURE_SSL_REDIRECT: bool = False
    SECURE_HSTS_SECONDS: int = 0
    SECURE_HSTS_INCLUDE_SUBDOMAINS: bool = False
    SECURE_HSTS_PRELOAD: bool = False
    SECURE_COOKIES: bool = False
    X_FRAME_OPTIONS: str = "DENY"
    SECURE_BROWSER_XSS_FILTER: bool = True
    SECURE_CONTENT_SECURITY_POLICY: dict[str, Any] | None = None

    # ── Rate Limiting ─────────────────────────────────────────────────────
    RATE_LIMIT_BACKEND: str = "memory"  # "memory" | "redis"
    RATE_LIMIT_REQUESTS: int = 1000000
    RATE_LIMIT_WINDOW: int = 60
    RATE_LIMIT_BY: str = "ip"  # "ip" | "user" | "path"

    # ── Background Tasks ─────────────────────────────────────────────────
    DRAMATIQ_BROKER: str = "redis"  # "redis" | "stub"
    DRAMATIQ_BROKER_URL: str = "redis://localhost:6379/0"

    # ── AI Integration ───────────────────────────────────────────────────
    AI_MODELS: dict[str, Any] = {}

    # ── OpenAPI / Swagger ─────────────────────────────────────────────────
    OPENAPI_TITLE: str = "MiNova API"
    OPENAPI_VERSION: str = "0.0.1"
    OPENAPI_DOCS_URL: str = "/open-api/docs"
    OPENAPI_REDOC_URL: str = "/open-api/redoc"
    OPENAPI_SCHEMA_URL: str = "/open-api/openapi.json"
    OPENAPI_ENABLED: bool = True

    # ── Monitoring ───────────────────────────────────────────────────────
    ENABLE_MONITORING: bool = False
    SENTRY_DSN: str = ""
    SENTRY_ENVIRONMENT: str = "development"
    SENTRY_SAMPLE_RATE: float = 0.1

    # ── File Uploads ──────────────────────────────────────────────────────
    MAX_FILE_SIZE: int = 10 * 1024 * 1024  # 10 MB default

    # ── S3 / Storage ─────────────────────────────────────────────────────
    STATIC_STORAGE: str = "local"  # "local" | "s3"
    MEDIA_STORAGE: str = "local"
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_STORAGE_BUCKET_NAME: str = ""

    def dict(self) -> dict[str, Any]:
        """Return all settings as a plain dict."""
        out: dict[str, Any] = {}
        for key in dir(self.__class__):
            if key.isupper():
                out[key] = getattr(self, key)
        # Instance overrides
        for key, val in vars(self).items():
            if key.isupper():
                out[key] = val
        return out

    def __getitem__(self, item: str) -> Any:
        return getattr(self, item)

    def __repr__(self) -> str:
        return f"<Settings PROJECT_NAME={self.PROJECT_NAME!r} DEBUG={self.DEBUG!r}>"


# ── Lazy global settings proxy ────────────────────────────────────────────────


class _LazySettings:
    """Proxy to the active Settings instance.

    Loaded lazily on first attribute access, allowing the module to be
    imported before configure() is called.
    """

    _instance: Settings | None = None

    def _setup(self, force: bool = False) -> None:
        if self._instance is not None and not force:
            return

        if force:
            self._instance = None

        # Load .env if present
        if _HAS_DOTENV:
            _load_dotenv(dotenv_path=".env", override=False)

        module_path = os.environ.get("MINOVA_SETTINGS_MODULE", "")
        if module_path:
            try:
                mod = importlib.import_module(module_path)

                # If during the import of the module, SettingsMeta already
                # initialized our instance (because ProjectSettings was defined),
                # we don't need to do anything else.
                if self._instance is not None and type(self._instance) is not Settings:
                    pass  # Keep going to see if we can find it in the module directly too

                # Find the Settings subclass in the module
                for name in dir(mod):
                    obj = getattr(mod, name)
                    if isinstance(obj, type) and issubclass(obj, Settings) and obj is not Settings:
                        self._instance = obj()
                        break
                else:
                    # Module itself might be a settings instance
                    if isinstance(mod, Settings):
                        self._instance = mod  # type: ignore[assignment]
                    elif self._instance is None:
                        self._instance = Settings()
            except ImportError as e:
                if os.environ.get("DEBUG"):
                    print(f"Warning: Could not import settings module {module_path!r}: {e}")
                if self._instance is None:
                    self._instance = Settings()
        elif SettingsMeta._subclasses:
            # Automatic discovery: use the last non-base Settings subclass found
            if self._instance is None or type(self._instance) is Settings:
                self._instance = SettingsMeta._subclasses[-1]()
        else:
            # Last resort: search sys.modules
            if self._instance is None or type(self._instance) is Settings:
                for mod in list(sys.modules.values()):
                    if not mod:
                        continue
                    try:
                        for name in dir(mod):
                            obj = getattr(mod, name)
                            if (
                                isinstance(obj, type)
                                and issubclass(obj, Settings)
                                and obj is not Settings
                            ):
                                self._instance = obj()
                                break
                        if self._instance and type(self._instance) is not Settings:
                            break
                    except (AttributeError, ImportError, TypeError):
                        continue

            if not self._instance:
                self._instance = Settings()

        # Merge project-defined MINOVA dict if present
        if hasattr(self._instance, "MINOVA") and isinstance(self._instance.MINOVA, dict):
            for key, val in self._instance.MINOVA.items():
                if key.isupper():
                    setattr(self._instance, key, val)

        # Apply env-var overrides (these take final priority)
        self._apply_env_overrides()

        # Auto-include the project app derived from MINOVA_SETTINGS_MODULE
        self._auto_include_project_app(module_path)

    def _auto_include_project_app(self, module_path: str) -> None:
        """Auto-include the project's own package as an installed app.

        Derives the project app name from ``MINOVA_SETTINGS_MODULE``
        (e.g. ``"myproject.settings"`` → ``"myproject"``) and prepends
        it to ``INSTALLED_APPS`` if not already present.
        """
        if self._instance is None or not module_path:
            return

        project_app = module_path.split(".")[0]
        if not project_app:
            return

        installed = getattr(self._instance, "INSTALLED_APPS", [])
        if project_app not in installed:
            self._instance.INSTALLED_APPS = [project_app] + list(installed)

    def _apply_env_overrides(self) -> None:
        if self._instance is None:
            return

        # We look at all uppercase attributes in both base and instance classes
        for key in dir(self._instance):
            if not key.isupper():
                continue

            val = os.environ.get(key)
            if val is None:
                continue

            default = getattr(self._instance, key)

            try:
                if isinstance(default, bool):
                    casted: Any = val.lower() in ("1", "true", "yes", "on")
                elif isinstance(default, int):
                    casted = int(val)
                elif isinstance(default, float):
                    casted = float(val)
                elif isinstance(default, list):
                    casted = [x.strip() for x in val.split(",")]
                elif isinstance(default, timedelta):
                    # For timedelta, we assume the env value is in seconds
                    casted = timedelta(seconds=int(val))
                else:
                    casted = val

                setattr(self._instance, key, casted)
            except (ValueError, TypeError):
                # If casting fails, we keep the default
                if os.environ.get("DEBUG"):
                    print(f"Warning: Could not cast env var {key!r}={val!r} to {type(default)}")
                continue

    def configure(self, settings_obj: Settings) -> None:
        """Programmatically configure the active settings."""
        self._instance = settings_obj

    def __getattr__(self, name: str) -> Any:
        self._setup()
        assert self._instance is not None
        return getattr(self._instance, name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith("_"):
            super().__setattr__(name, value)
        else:
            self._setup()
            assert self._instance is not None
            setattr(self._instance, name, value)


settings = _LazySettings()


def validate_settings(s: Settings, env: str) -> None:
    """Validate settings for the given environment.

    Raises:
        SettingsValidationError: If any validation check fails.
    """

    errors: list[str] = []

    if env == "production":
        if s.DEBUG:
            errors.append("DEBUG must be False in production.")
        if not s.SECRET_KEY or s.SECRET_KEY in (
            "INSECURE-CHANGE-ME",
            "dev-insecure-key",
        ):
            errors.append("SECRET_KEY must be set to a strong random value in production.")
        elif len(s.SECRET_KEY) < 50:
            errors.append("SECRET_KEY must be at least 50 characters long in production.")
        if not s.SECURE_COOKIES:
            errors.append("SECURE_COOKIES must be True in production.")
        if not s.ALLOWED_HOSTS:
            errors.append("ALLOWED_HOSTS must contain at least one entry in production.")

    if not s.DATABASE_URL:
        errors.append("DATABASE_URL must be set.")

    if errors:
        raise SettingsValidationError(errors)


def generate_secret_key(length: int = 64) -> str:
    """Generate a cryptographically secure secret key."""
    return secrets.token_urlsafe(length)
