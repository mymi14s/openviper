"""MiNova contrib packages — optional, batteries-included features."""
