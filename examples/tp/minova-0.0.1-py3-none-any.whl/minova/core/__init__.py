"""MiNova core package."""
