"""runworker management command — start background task worker."""

from __future__ import annotations

import argparse
import os
import signal
import subprocess
import sys

from minova.conf import settings
from minova.core.app_resolver import AppResolver
from minova.core.management.base import BaseCommand
from minova.tasks.worker import run_worker


class Command(BaseCommand):
    help = "Start a background task worker process (Dramatiq or Database)."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "modules",
            nargs="*",
            help="Python module paths that contain task definitions (e.g. myapp.tasks)",
        )
        parser.add_argument(
            "--queues",
            "-Q",
            nargs="*",
            default=None,
            help="Only process messages from these queues",
        )
        parser.add_argument(
            "--processes",
            "-p",
            type=int,
            default=1,
            help="Number of worker processes (default: 1)",
        )
        parser.add_argument(
            "--threads",
            "-t",
            type=int,
            default=8,
            help="Threads per process (default: 8)",
        )

    def handle(self, **options):  # type: ignore[override]
        try:
            import dramatiq  # noqa: F401
        except ImportError:
            self.stderr(self.style_error("dramatiq is required: pip install 'minova[tasks]'"))
            sys.exit(1)

        # Determine backend
        tasks_config = getattr(settings, "TASKS", {})
        backend = tasks_config.get("BACKEND", "redis")

        if backend == "database":
            self.stdout("Starting Database-backed worker...")
            run_worker(
                processes=options["processes"],
                threads=options["threads"],
                queues=options["queues"],
            )
        else:
            # Traditional Dramatiq (Redis/Stub)
            modules = list(options.get("modules") or [])

            if not modules:
                try:
                    resolver = AppResolver()
                    for app_name in getattr(settings, "INSTALLED_APPS", []):
                        # Skip framework-internal apps
                        if app_name.startswith("minova."):
                            continue
                        app_path, found = resolver.resolve_app(app_name)
                        if found and app_path:
                            for root, dirs, files in os.walk(app_path):
                                dirs[:] = [
                                    d
                                    for d in dirs
                                    if d not in ("migrations", "tests", "__pycache__")
                                ]
                                for file in files:
                                    if file.endswith(".py") and file != "__init__.py":
                                        # Build dotted path from app_name + relative subpath
                                        rel_path = os.path.relpath(
                                            os.path.join(root, file), app_path
                                        )
                                        submodule = rel_path[:-3].replace(os.sep, ".")
                                        if submodule == ".":
                                            modules.append(app_name)
                                        else:
                                            modules.append(f"{app_name}.{submodule}")
                except ImportError:
                    pass

            if not modules:
                self.stdout("No task modules specified or found.")
                sys.exit(1)

            # minova.tasks must be the first positional arg — it is the broker module
            # that calls dramatiq.set_broker() on import.
            broker_module = "minova.tasks"
            all_positional = [broker_module] + modules

            args = [sys.executable, "-m", "dramatiq"]
            if options.get("queues"):
                args += ["--queues"] + options["queues"]
            args += ["--processes", str(options["processes"])]
            args += ["--threads", str(options["threads"])]
            args += all_positional

            self.stdout(f"Starting Dramatiq worker ({backend}): {' '.join(args)}")

            env = os.environ.copy()
            python_path = env.get("PYTHONPATH", "")
            project_root = os.getcwd()
            if python_path:
                env["PYTHONPATH"] = f"{project_root}{os.pathsep}{python_path}"
            else:
                env["PYTHONPATH"] = project_root

            proc = subprocess.Popen(args, env=env)
            try:
                proc.wait()
            except KeyboardInterrupt:
                # Ctrl+C: give Dramatiq a chance to clean up semaphores
                self.stdout("Shutting down worker (SIGTERM)...")
                proc.send_signal(signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
            sys.exit(proc.returncode or 0)
