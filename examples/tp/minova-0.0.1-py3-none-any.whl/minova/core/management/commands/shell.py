"""shell management command — interactive Python REPL with MiNova context."""

from __future__ import annotations

import argparse
import code
import importlib
import inspect
import logging

from minova import MiNova, Request
from minova.auth import get_user_model
from minova.conf import settings
from minova.core.management.base import BaseCommand
from minova.db.models import Model
from minova.http.response import HTMLResponse, JSONResponse

logger = logging.getLogger("minova.shell")


class Command(BaseCommand):
    help = "Start an interactive Python shell with MiNova pre-imported."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "--ipython",
            action="store_true",
            help="Force IPython shell (default if available)",
        )
        parser.add_argument(
            "--plain",
            action="store_true",
            help="Force plain Python shell (no IPython)",
        )
        parser.add_argument(
            "--no-models",
            action="store_true",
            help="Don't auto-import models from apps",
        )
        parser.add_argument(
            "-c",
            "--command",
            help="Execute the given command string and exit",
        )

    def _discover_models(self) -> dict[str, type]:
        """Discover and return all Model subclasses from INSTALLED_APPS.

        Each app in ``INSTALLED_APPS`` is probed for a ``models`` module.
        Classes that are direct or indirect subclasses of :class:`Model`
        and are *defined* in that module (not just imported) are collected.

        Returns:
            Mapping of class name → class object, ready to inject into a
            shell namespace.
        """
        models: dict[str, type] = {}
        installed_apps: list[str] = getattr(settings, "INSTALLED_APPS", [])

        for app in installed_apps:
            # Skip framework internal apps unless they have models
            module_name = f"{app}.models" if not app.endswith(".models") else app
            try:
                module = importlib.import_module(module_name)
            except ImportError as exc:
                logger.debug("Could not import %s: %s", module_name, exc)
                continue

            found_in_module = 0
            for name, obj in inspect.getmembers(module, inspect.isclass):
                try:
                    if (
                        issubclass(obj, Model)
                        and obj is not Model
                        and obj.__module__ == module.__name__
                    ):
                        models[name] = obj
                        found_in_module += 1
                except TypeError:
                    continue

            if found_in_module:
                self.stdout(
                    f"  {self.style_success('✓')} Found {found_in_module} models in "
                    f"{self.style_bold(module_name)}"
                )

        # Always attempt to include the configured User model.
        try:
            user_cls = get_user_model()
            if user_cls.__name__ not in models:
                models[user_cls.__name__] = user_cls
                self.stdout(
                    f"  {self.style_success('✓')} Found User model: "
                    f"{self.style_bold(user_cls.__name__)}"
                )
        except Exception:
            pass

        return models

    def _build_namespace(self, include_models: bool) -> tuple[dict[str, object], list[str]]:
        """Build the shell namespace and return it alongside a sorted model list.

        Returns:
            (namespace dict, sorted list of model names that were injected)
        """
        ns: dict[str, object] = {}

        try:
            ns.update(
                {
                    "settings": settings,
                    "MiNova": MiNova,
                    "Request": Request,
                    "JSONResponse": JSONResponse,
                    "HTMLResponse": HTMLResponse,
                }
            )
        except Exception as exc:
            logger.debug("Could not import MiNova core objects: %s", exc)

        model_names: list[str] = []
        if include_models:
            models = self._discover_models()
            ns.update(models)
            model_names = sorted(models.keys())

        return ns, model_names

    def _build_banner(self, model_names: list[str]) -> str:
        """Build the startup banner shown in the shell."""
        version = getattr(importlib.import_module("minova"), "__version__", "?")
        project_name = getattr(settings, "PROJECT_NAME", "unknown")

        lines = [
            f"MiNova {version} — interactive shell",
            f"Project : {project_name}",
        ]
        if model_names:
            # Wrap model names at ~72 chars so the banner stays readable.
            model_line = ", ".join(model_names)
            lines.append(f"Models  : {model_line}")

        lines.append("Tip     : type 'exit()' or Ctrl-D to quit.")
        return "\n".join(lines) + "\n"

    # ── Shell launchers ───────────────────────────────────────────────────────

    def _launch_ipython(self, ns: dict[str, object], banner: str) -> bool:
        """Try to start an IPython shell using embed()."""
        try:
            from IPython import embed
            from traitlets.config import Config
        except ImportError:
            return False

        # Config to handle auto-await and other conveniences
        cfg = Config()
        cfg.InteractiveShell.confirm_exit = False
        cfg.InteractiveShell.autoawait = True

        # Build a short summary of what was injected
        objs = [n for n in sorted(ns) if n[0].isupper() or n == "settings"]
        summary = f"# Pre-imported: {', '.join(objs)}\n"

        embed(
            user_ns=ns,
            banner1=banner + summary,
            config=cfg,
            colors="Neutral",
            using="asyncio",
        )
        return True

    def _launch_plain(self, ns: dict[str, object], banner: str) -> None:
        """Start the stdlib interactive console."""
        shell = code.InteractiveConsole(locals=ns)
        shell.interact(banner=banner)

    # ── Entry point ───────────────────────────────────────────────────────────

    def handle(self, **options) -> None:  # type: ignore[override]
        self.stdout(self.style_bold("\n# MiNova Shell Startup"))
        include_models = not options.get("no_models", False)
        ns, model_names = self._build_namespace(include_models)
        banner = self._build_banner(model_names)
        self.stdout("")

        command = options.get("command")
        if command:
            exec(command, ns)  # noqa: S102
            return

        force_plain = options.get("plain", False)
        force_ipython = options.get("ipython", True)

        # Auto-detect IPython when neither flag is given.
        if not force_plain:
            force_ipython = True

        if force_ipython and not force_plain:
            started = self._launch_ipython(ns, banner)
            if not started:
                self.stderr(
                    self.style_warning("IPython not available, falling back to plain shell.")
                )
                self._launch_plain(ns, banner)
            return

        self._launch_plain(ns, banner)
