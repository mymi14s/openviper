"""test management command."""

from __future__ import annotations

import argparse
import subprocess
import sys

from minova.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Run the project test suite using pytest."

    def add_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            "test_labels",
            nargs="*",
            help="Specific test paths/labels to run (passed directly to pytest)",
        )
        parser.add_argument("--verbosity", "-v", type=int, default=1)
        parser.add_argument(
            "--coverage",
            action="store_true",
            help="Run with pytest-cov coverage reporting",
        )
        parser.add_argument(
            "--failfast",
            "-x",
            action="store_true",
            help="Stop on first failure",
        )
        parser.add_argument(
            "--keepdb",
            action="store_true",
            help="Preserve test database across runs",
        )

    def handle(self, **options):  # type: ignore[override]

        args = [sys.executable, "-m", "pytest"]

        if options.get("verbosity", 1) >= 2:
            args.append("-v")

        if options.get("failfast"):
            args.append("-x")

        if options.get("coverage"):
            args += ["--cov=.", "--cov-report=term-missing"]

        test_labels = options.get("test_labels") or []
        args += test_labels if test_labels else ["tests/"]

        self.stdout(f"Running: {' '.join(args)}")
        result = subprocess.run(args, env={**os.environ, "MINOVA_ENV": "testing"})
        sys.exit(result.returncode)


import os
