"""Database connection management using SQLAlchemy async engine."""

from __future__ import annotations

from typing import Any

import sqlalchemy as sa
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine, create_async_engine
from sqlalchemy.pool import StaticPool

_engine: AsyncEngine | None = None
_metadata: sa.MetaData = sa.MetaData()


def get_metadata() -> sa.MetaData:
    return _metadata


async def get_engine() -> AsyncEngine:
    """Return (or lazily create) the shared async engine."""
    global _engine
    if _engine is None:
        from minova.conf import settings as _settings

        _engine = _create_engine(_settings.DATABASE_URL, _settings.DATABASE_ECHO)
    return _engine


def _create_engine(url: str, echo: bool = False) -> AsyncEngine:
    """Create an async SQLAlchemy engine from a database URL.

    Translates sync-driver URLs to their async equivalents automatically.
    """
    # Translate sync driver URLs to async
    replacements = {
        "sqlite:///": "sqlite+aiosqlite:///",
        "sqlite://": "sqlite+aiosqlite://",
        "postgresql://": "postgresql+asyncpg://",
        "postgres://": "postgresql+asyncpg://",
        "mysql://": "mysql+aiomysql://",
        "mariadb://": "mysql+aiomysql://",
    }
    async_url = url
    for old, new in replacements.items():
        if url.startswith(old):
            async_url = new + url[len(old) :]
            break

    kwargs: dict[str, Any] = {"echo": echo}

    # SQLite in-memory needs a static pool to persist across connections
    if ":memory:" in async_url:
        kwargs["connect_args"] = {"check_same_thread": False}
        kwargs["poolclass"] = StaticPool

    engine = create_async_engine(async_url, **kwargs)

    # Enable Foreign Keys for SQLite
    if "sqlite" in async_url:

        @sa.event.listens_for(engine.sync_engine, "connect")
        def set_sqlite_pragma(dbapi_connection, connection_record):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    return engine


async def get_connection() -> AsyncConnection:
    """Return an async database connection from the pool."""
    engine = await get_engine()
    return engine.connect()


async def init_db(drop_first: bool = False) -> None:
    """Create all registered tables.  Optionally drop them first.

    Args:
        drop_first: If True, drop all tables before creating them.
    """
    engine = await get_engine()
    async with engine.begin() as conn:
        if drop_first:
            await conn.run_sync(_metadata.drop_all)
        await conn.run_sync(_metadata.create_all)


async def close_db() -> None:
    """Dispose the engine and all pooled connections."""
    global _engine
    if _engine is not None:
        await _engine.dispose()
        _engine = None


async def configure_db(database_url: str, echo: bool = False) -> None:
    """Explicitly configure the database engine (call before init_db)."""
    global _engine
    _engine = _create_engine(database_url, echo)
