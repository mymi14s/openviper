"""Low-level SQL execution helpers used by the ORM layer."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import sqlalchemy as sa

from minova.db.connection import get_engine, get_metadata
from minova.db.fields import (
    BigIntegerField,
    BinaryField,
    BooleanField,
    CharField,
    DateField,
    DateTimeField,
    DecimalField,
    FileField,
    FloatField,
    ForeignKey,
    IntegerField,
    JSONField,
    OneToOneField,
    TimeField,
    UUIDField,
)
from minova.conf import settings
from minova.db.migrations.executor import _get_soft_removed_table

if TYPE_CHECKING:
    from minova.db.models import Model, QuerySet

_TABLE_CACHE: dict[str, sa.Table] = {}

# Cache of soft-removed columns: {table_name: {column_name, ...}}
_SOFT_REMOVED_CACHE: dict[str, set[str]] = {}
_SOFT_REMOVED_LOADED: bool = False


async def _load_soft_removed_columns() -> None:
    """Load soft-removed column info from the tracking table into cache."""
    global _SOFT_REMOVED_LOADED
    if _SOFT_REMOVED_LOADED:
        return
    try:
        engine = await get_engine()
        soft_table = _get_soft_removed_table()
        async with engine.connect() as conn:
            # Check if the table exists first
            exists = await conn.run_sync(
                lambda sync_conn: sa.inspect(sync_conn).has_table(soft_table.name)
            )
            if not exists:
                _SOFT_REMOVED_LOADED = True
                return
            result = await conn.execute(
                sa.select(soft_table.c.table_name, soft_table.c.column_name)
            )
            for row in result:
                _SOFT_REMOVED_CACHE.setdefault(row.table_name, set()).add(row.column_name)
        _SOFT_REMOVED_LOADED = True
    except Exception:
        # If the table doesn't exist yet, that's fine — no columns removed
        _SOFT_REMOVED_LOADED = True


def invalidate_soft_removed_cache() -> None:
    """Clear the soft-removed column cache (call after migrations)."""
    global _SOFT_REMOVED_LOADED
    _SOFT_REMOVED_CACHE.clear()
    _SOFT_REMOVED_LOADED = False


def get_soft_removed_columns(table_name: str) -> set[str]:
    """Return the set of soft-removed column names for a table (sync).

    Must call ``_load_soft_removed_columns()`` first in an async context.
    """
    return _SOFT_REMOVED_CACHE.get(table_name, set())


# ── Table registration ────────────────────────────────────────────────────────


def get_table(model_cls: type[Model]) -> sa.Table:
    """Return (or lazily build) the SQLAlchemy Table for a model class."""
    table_name = model_cls._table_name
    if table_name in _TABLE_CACHE:
        return _TABLE_CACHE[table_name]

    metadata = get_metadata()
    columns: list[sa.Column] = []
    added_columns: set[str] = set()
    for _name, field in model_cls._fields.items():
        if field._column_type == "":
            continue  # ManyToMany — no column

        col_name = field.column_name
        if col_name in added_columns:
            continue

        col_type = _sa_type(field)
        args = [col_name, col_type]

        # Add ForeignKey constraint if applicable
        if isinstance(field, (ForeignKey, OneToOneField)):
            related_table = ""
            if not isinstance(field.to, str):
                related_table = getattr(field.to, "_table_name", "")
            else:
                # String reference: app.models.Model -> app_model
                if "." in field.to:
                    parts = field.to.split(".")
                    related_table = f"{parts[0]}_{parts[-1].lower()}"
                else:
                    related_table = field.to.lower()

            if related_table:
                args.append(sa.ForeignKey(f"{related_table}.id", ondelete=field.on_delete))

        col_kwargs: dict[str, Any] = {
            "nullable": field.null,
            "unique": field.unique,
            "index": field.db_index,
        }
        if field.primary_key:
            col_kwargs["primary_key"] = True
        if field.auto_increment and field.primary_key:
            col_kwargs["autoincrement"] = True
        if field.default is not None and not callable(field.default):
            col_kwargs["default"] = field.default

        col = sa.Column(*args, **col_kwargs)
        columns.append(col)
        added_columns.add(col_name)

    table = sa.Table(table_name, metadata, *columns)
    _TABLE_CACHE[table_name] = table
    return table


def _sa_type(field: Any) -> sa.types.TypeEngine:

    if isinstance(field, BinaryField):
        return sa.LargeBinary()
    if isinstance(field, (ForeignKey, OneToOneField)):
        return sa.Integer()
    if isinstance(field, BigIntegerField):
        return sa.BigInteger()
    if isinstance(field, IntegerField):
        return sa.Integer()
    if isinstance(field, FloatField):
        return sa.Float()
    if isinstance(field, DecimalField):
        return sa.Numeric(precision=field.max_digits, scale=field.decimal_places)
    if isinstance(field, BooleanField):
        return sa.Boolean()
    if isinstance(field, DateTimeField):
        return sa.DateTime(timezone=settings.USE_TZ)
    if isinstance(field, DateField):
        return sa.Date()
    if isinstance(field, TimeField):
        return sa.Time()
    if isinstance(field, UUIDField):
        return sa.String(36)
    if isinstance(field, JSONField):
        return sa.JSON()
    if isinstance(field, FileField):
        return sa.String(field.max_length)
    if isinstance(field, CharField):
        return sa.String(field.max_length)
    return sa.Text()


# ── Filter compiler ───────────────────────────────────────────────────────────


def _compile_filters(
    table: sa.Table, filter_dicts: list[dict[str, Any]]
) -> sa.ColumnElement | None:
    """Convert ORM filters to SQLAlchemy where clauses.

    Supports: ``field=val``, ``field__exact``, ``field__contains``,
    ``field__icontains``, ``field__startswith``, ``field__endswith``,
    ``field__gt``, ``field__gte``, ``field__lt``, ``field__lte``,
    ``field__in``, ``field__isnull``.
    """
    clauses: list[sa.ColumnElement] = []
    for filters in filter_dicts:
        for key, value in filters.items():
            parts = key.split("__", 1)
            col_name = parts[0]
            lookup = parts[1] if len(parts) > 1 else "exact"

            # Support FK _id column aliases
            if col_name not in table.c and f"{col_name}_id" in table.c:
                col_name = f"{col_name}_id"

            if col_name not in table.c:
                continue

            col = table.c[col_name]

            if lookup == "exact":
                clauses.append(col == value)
            elif lookup == "contains":
                clauses.append(col.like(f"%{value}%"))
            elif lookup == "icontains":
                clauses.append(col.ilike(f"%{value}%"))
            elif lookup == "startswith":
                clauses.append(col.like(f"{value}%"))
            elif lookup == "endswith":
                clauses.append(col.like(f"%{value}"))
            elif lookup == "gt":
                clauses.append(col > value)
            elif lookup == "gte":
                clauses.append(col >= value)
            elif lookup == "lt":
                clauses.append(col < value)
            elif lookup == "lte":
                clauses.append(col <= value)
            elif lookup == "in":
                clauses.append(col.in_(value))
            elif lookup == "isnull":
                clauses.append(col.is_(None) if value else col.isnot(None))
            elif lookup == "range":
                lo, hi = value
                clauses.append(col.between(lo, hi))
            else:
                clauses.append(col == value)

    return sa.and_(*clauses) if clauses else None


def _compile_excludes(
    table: sa.Table, exclude_dicts: list[dict[str, Any]]
) -> sa.ColumnElement | None:
    filters_clause = _compile_filters(table, exclude_dicts)
    if filters_clause is None:
        return None
    return sa.not_(filters_clause)


# ── Execute helpers ───────────────────────────────────────────────────────────


async def execute_select(qs: QuerySet) -> list[dict[str, Any]]:
    model_cls = qs._model
    table = get_table(model_cls)
    stmt = sa.select(table)

    where_parts: list[sa.ColumnElement] = []
    f = _compile_filters(table, qs._filters)
    if f is not None:
        where_parts.append(f)
    e = _compile_excludes(table, qs._excludes)
    if e is not None:
        where_parts.append(e)
    if where_parts:
        stmt = stmt.where(sa.and_(*where_parts))

    for field_name in qs._order:
        desc = field_name.startswith("-")
        col_name = field_name.lstrip("-")
        if col_name in table.c:
            col = table.c[col_name]
            stmt = stmt.order_by(col.desc() if desc else col.asc())

    if qs._limit is not None:
        stmt = stmt.limit(qs._limit)
    if qs._offset is not None:
        stmt = stmt.offset(qs._offset)

    engine = await get_engine()
    async with engine.connect() as conn:
        result = await conn.execute(stmt)
        return [dict(row._mapping) for row in result]


async def execute_count(qs: QuerySet) -> int:
    model_cls = qs._model
    table = get_table(model_cls)
    stmt = sa.select(sa.func.count()).select_from(table)

    where_parts: list[sa.ColumnElement] = []
    f = _compile_filters(table, qs._filters)
    if f is not None:
        where_parts.append(f)
    e = _compile_excludes(table, qs._excludes)
    if e is not None:
        where_parts.append(e)
    if where_parts:
        stmt = stmt.where(sa.and_(*where_parts))

    engine = await get_engine()
    async with engine.connect() as conn:
        result = await conn.execute(stmt)
        return result.scalar_one()


async def execute_delete(qs: QuerySet) -> int:
    model_cls = qs._model
    table = get_table(model_cls)
    stmt = sa.delete(table)

    where_parts: list[sa.ColumnElement] = []
    f = _compile_filters(table, qs._filters)
    if f is not None:
        where_parts.append(f)
    if where_parts:
        stmt = stmt.where(sa.and_(*where_parts))

    engine = await get_engine()
    async with engine.begin() as conn:
        result = await conn.execute(stmt)
        return result.rowcount


async def execute_update(qs: QuerySet, values: dict[str, Any]) -> int:
    model_cls = qs._model
    table = get_table(model_cls)

    field_defs = model_cls._fields
    db_values: dict[str, Any] = {}
    for k, v in values.items():
        if k in field_defs:
            db_values[field_defs[k].column_name] = field_defs[k].to_db(v)
        else:
            db_values[k] = v

    stmt = sa.update(table).values(**db_values)

    where_parts: list[sa.ColumnElement] = []
    f = _compile_filters(table, qs._filters)
    if f is not None:
        where_parts.append(f)
    if where_parts:
        stmt = stmt.where(sa.and_(*where_parts))

    engine = await get_engine()
    async with engine.begin() as conn:
        result = await conn.execute(stmt)
        return result.rowcount


async def execute_save(instance: Model) -> None:
    """INSERT or UPDATE a single model instance."""
    model_cls = type(instance)
    table = get_table(model_cls)
    instance._apply_auto_fields()

    # Load soft-removed columns so we can skip them
    await _load_soft_removed_columns()
    soft_removed = get_soft_removed_columns(model_cls._table_name)

    data = {}
    for name, field in model_cls._fields.items():
        if field.primary_key and field.auto_increment and getattr(instance, name) is None:
            continue
        # Skip soft-removed columns — they are no longer part of the model
        if field.column_name in soft_removed:
            continue
        data[field.column_name] = field.to_db(getattr(instance, name))

    engine = await get_engine()
    pk_val = getattr(instance, "id", None)

    if pk_val is None:
        stmt = sa.insert(table).values(**data)
        async with engine.begin() as conn:
            result = await conn.execute(stmt)
            instance.id = result.inserted_primary_key[0]
    else:
        stmt = sa.update(table).where(table.c.id == pk_val).values(**data)
        async with engine.begin() as conn:
            await conn.execute(stmt)


async def execute_delete_instance(instance: Model) -> None:
    model_cls = type(instance)
    table = get_table(model_cls)
    pk_val = instance.id

    engine = await get_engine()
    async with engine.begin() as conn:
        await conn.execute(sa.delete(table).where(table.c.id == pk_val))
