"""MiNova exception hierarchy."""

from __future__ import annotations

from http import HTTPStatus
from typing import Any


class MiNovaException(Exception):
    """Base exception for all MiNova errors."""


class ImproperlyConfigured(MiNovaException):
    """Framework or application is incorrectly configured."""


class SettingsValidationError(MiNovaException):
    """Settings failed validation on startup."""

    def __init__(self, errors: list[str]) -> None:
        self.errors = errors
        super().__init__("\n".join(f"  - {e}" for e in errors))


class HTTPException(MiNovaException):
    """Raised to return an HTTP error response.

    Args:
        status_code: HTTP status code.
        detail: Human-readable error detail.
        headers: Optional extra headers to include in the response.
    """

    def __init__(
        self,
        status_code: int,
        detail: Any = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.status_code = status_code
        self.detail = detail if detail is not None else self._default_detail()
        self.headers = headers or {}
        super().__init__(f"HTTP {status_code}: {self.detail}")

    def _default_detail(self) -> str:
        try:
            return HTTPStatus(self.status_code).phrase
        except ValueError:
            return "Error"


class NotFound(HTTPException):
    """404 Not Found."""

    def __init__(self, detail: str = "Not found.", headers: dict[str, str] | None = None) -> None:
        super().__init__(404, detail, headers)


class MethodNotAllowed(HTTPException):
    """405 Method Not Allowed."""

    def __init__(self, allowed: list[str]) -> None:
        super().__init__(
            405,
            "Method not allowed.",
            {"Allow": ", ".join(allowed)},
        )


class PermissionDenied(HTTPException):
    """403 Forbidden."""

    def __init__(self, detail: str = "Permission denied.") -> None:
        super().__init__(403, detail)


class Unauthorized(HTTPException):
    """401 Unauthorized."""

    def __init__(self, detail: str = "Authentication required.") -> None:
        super().__init__(401, detail, {"WWW-Authenticate": "Bearer"})


class ValidationError(HTTPException):
    """422 Unprocessable Entity — request body / parameter validation failure."""

    def __init__(self, errors: Any) -> None:
        self.validation_errors = errors
        super().__init__(422, errors)


class Conflict(HTTPException):
    """409 Conflict."""

    def __init__(self, detail: str = "Conflict.") -> None:
        super().__init__(409, detail)


class TooManyRequests(HTTPException):
    """429 Too Many Requests."""

    def __init__(self, retry_after: int | None = None) -> None:
        headers = {}
        if retry_after is not None:
            headers["Retry-After"] = str(retry_after)
        super().__init__(429, "Too many requests.", headers)


class ServiceUnavailable(HTTPException):
    """503 Service Unavailable."""

    def __init__(self, detail: str = "Service unavailable.") -> None:
        super().__init__(503, detail)


class ORMException(MiNovaException):
    """Base ORM error."""


class DoesNotExist(ORMException):
    """Record not found."""


class MultipleObjectsReturned(ORMException):
    """Query returned more than one record when exactly one was expected."""


class IntegrityError(ORMException):
    """Database integrity constraint violated."""


class MigrationError(MiNovaException):
    """Migration could not be applied or reversed."""


class AuthenticationFailed(HTTPException):
    """Authentication attempt failed."""

    def __init__(self, detail: str = "Invalid credentials.") -> None:
        super().__init__(401, detail, {"WWW-Authenticate": "Bearer"})


class TokenExpired(AuthenticationFailed):
    """JWT or session token has expired."""

    def __init__(self) -> None:
        super().__init__("Token has expired.")


class MiddlewareException(MiNovaException):
    """Error raised within the middleware pipeline."""
