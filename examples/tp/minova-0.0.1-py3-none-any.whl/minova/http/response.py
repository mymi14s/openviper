"""HTTP Response classes for MiNova."""

from __future__ import annotations

import datetime
import gzip
import json
import mimetypes
import os
import stat
import uuid
from collections.abc import AsyncIterator, Callable, Iterator
from pathlib import Path
from typing import Any

from minova.utils.datastructures import MutableHeaders

try:
    from jinja2 import Environment, FileSystemLoader
except ImportError:
    Environment = None  # type: ignore[misc,assignment]
    FileSystemLoader = None  # type: ignore[misc,assignment]


class Response:
    """Base HTTP response.

    Args:
        content: Response body. Bytes, str, or None.
        status_code: HTTP status code (default 200).
        headers: Optional dict of headers to set.
        media_type: Content-Type MIME type.
    """

    media_type: str | None = None
    charset: str = "utf-8"

    def __init__(
        self,
        content: Any = None,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        media_type: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.media_type = media_type or self.__class__.media_type  # type: ignore[assignment]
        self._headers = MutableHeaders(raw=self._build_raw_headers(headers or {}))
        self.body = self._encode(content)

    # ── Internals ─────────────────────────────────────────────────────────

    def _encode(self, content: Any) -> bytes:
        if content is None:
            return b""
        if isinstance(content, bytes):
            return content
        if isinstance(content, str):
            return content.encode(self.charset)
        raise TypeError(f"Response content must be str or bytes, not {type(content).__name__}")

    def _build_raw_headers(self, extra: dict[str, str]) -> list[list[bytes]]:
        raw: list[list[bytes]] = []
        # Content-Type
        content_type = self.media_type
        if content_type and "charset" not in content_type and "text" in content_type:
            content_type = f"{content_type}; charset={self.charset}"
        if content_type:
            raw.append([b"content-type", content_type.encode("latin-1")])
        for k, v in extra.items():
            raw.append([k.lower().encode("latin-1"), v.encode("latin-1")])
        return raw

    @property
    def headers(self) -> MutableHeaders:
        return self._headers

    def set_cookie(
        self,
        key: str,
        value: str = "",
        max_age: int | None = None,
        expires: int | None = None,
        path: str = "/",
        domain: str | None = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: str = "lax",
    ) -> None:
        """Append a Set-Cookie header."""
        cookie = f"{key}={value}"
        if max_age is not None:
            cookie += f"; Max-Age={max_age}"
        if expires is not None:
            cookie += f"; Expires={expires}"
        if path:
            cookie += f"; Path={path}"
        if domain:
            cookie += f"; Domain={domain}"
        if secure:
            cookie += "; Secure"
        if httponly:
            cookie += "; HttpOnly"
        cookie += f"; SameSite={samesite.capitalize()}"
        self._headers.append("set-cookie", cookie)

    def delete_cookie(self, key: str, path: str = "/", domain: str | None = None) -> None:
        self.set_cookie(key, "", max_age=0, path=path, domain=domain)

    # ── ASGI ──────────────────────────────────────────────────────────────

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:  # noqa: ARG002
        body = self.body
        if body:
            self._headers.set("content-length", str(len(body)))
        await send(
            {
                "type": "http.response.start",
                "status": self.status_code,
                "headers": self._headers.raw,
            }
        )
        await send({"type": "http.response.body", "body": body, "more_body": False})


class JSONResponse(Response):
    """JSON response. Content is serialized with json.dumps."""

    media_type = "application/json"

    def __init__(
        self,
        content: Any = None,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        indent: int | None = None,
    ) -> None:
        # Serialize before passing to parent
        encoded = json.dumps(content, default=self._default_encoder, indent=indent)
        super().__init__(encoded, status_code, headers)

    @staticmethod
    def _default_encoder(obj: Any) -> Any:
        if isinstance(obj, (datetime.datetime, datetime.date)):
            return obj.isoformat()
        if isinstance(obj, uuid.UUID):
            return str(obj)
        raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


class HTMLResponse(Response):
    """HTML response with optional template rendering."""

    media_type = "text/html"

    def __init__(
        self,
        content: Any = None,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        template: str | None = None,
        context: dict[str, Any] | None = None,
        template_dir: str | Path = "templates",
    ) -> None:
        """Initialize HTMLResponse.

        Args:
            content: Direct HTML content (str or bytes)
            status_code: HTTP status code
            headers: Optional headers dict
            template: Template filename to render (alternative to content)
            context: Template context variables (used with template)
            template_dir: Directory containing templates (default: "templates")
        """
        if template and content is not None:
            raise ValueError("Cannot specify both 'content' and 'template'")

        if template:
            if Environment is None:
                raise ImportError("jinja2 is required for template rendering")
            content = self._render_template(template, context or {}, template_dir)

        super().__init__(content, status_code, headers)

    def _render_template(
        self, template: str, context: dict[str, Any], template_dir: str | Path
    ) -> str:
        """Render a Jinja2 template."""
        env = Environment(loader=FileSystemLoader(template_dir))
        template_obj = env.get_template(template)
        return template_obj.render(**context)


class PlainTextResponse(Response):
    """Plain text response."""

    media_type = "text/plain"


class RedirectResponse(Response):
    """HTTP redirect response (3xx)."""

    def __init__(
        self,
        url: str,
        status_code: int = 307,
        headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(b"", status_code, {**(headers or {}), "location": url})


class StreamingResponse(Response):
    """Response with chunked body from an async generator or iterator."""

    def __init__(
        self,
        content: AsyncIterator[bytes] | Iterator[bytes] | Callable[[], AsyncIterator[bytes]],
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        media_type: str | None = None,
    ) -> None:
        self._content_iterator = content
        self.status_code = status_code
        self.media_type = media_type or "application/octet-stream"
        self._headers = MutableHeaders(raw=self._build_raw_headers(headers or {}))
        self.body = b""  # Not used in streaming

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:  # noqa: ARG002
        await send(
            {
                "type": "http.response.start",
                "status": self.status_code,
                "headers": self._headers.raw,
            }
        )
        iterator = self._content_iterator
        if callable(iterator):
            iterator = iterator()
        if hasattr(iterator, "__aiter__"):
            async for chunk in iterator:  # type: ignore[union-attr]
                await send({"type": "http.response.body", "body": chunk, "more_body": True})
        else:
            for chunk in iterator:  # type: ignore[union-attr]
                await send({"type": "http.response.body", "body": chunk, "more_body": True})
        await send({"type": "http.response.body", "body": b"", "more_body": False})


class FileResponse(Response):
    """Serve a file from disk with range and conditional request support."""

    chunk_size: int = 65536

    def __init__(
        self,
        path: str,
        status_code: int = 200,
        headers: dict[str, str] | None = None,
        media_type: str | None = None,
        filename: str | None = None,
    ) -> None:
        self.file_path = path
        self.status_code = status_code
        _media_type = media_type or self._guess_media_type(path)
        self.media_type = _media_type
        extra_headers = dict(headers or {})
        if filename:
            extra_headers["content-disposition"] = f'attachment; filename="{filename}"'
        fstat = os.stat(path)
        extra_headers["content-length"] = str(fstat[stat.ST_SIZE])
        extra_headers["last-modified"] = str(int(fstat[stat.ST_MTIME]))
        self._headers = MutableHeaders(raw=self._build_raw_headers(extra_headers))
        self.body = b""  # Streaming

    @staticmethod
    def _guess_media_type(path: str) -> str:
        mt, _ = mimetypes.guess_type(path)
        return mt or "application/octet-stream"

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:  # noqa: ARG002
        await send(
            {
                "type": "http.response.start",
                "status": self.status_code,
                "headers": self._headers.raw,
            }
        )
        with open(self.file_path, "rb") as f:
            while True:
                chunk = f.read(self.chunk_size)
                if not chunk:
                    break
                await send({"type": "http.response.body", "body": chunk, "more_body": True})
        await send({"type": "http.response.body", "body": b"", "more_body": False})


class GZipResponse(Response):
    """Response with gzip-compressed body."""

    def __init__(self, content: Response, minimum_size: int = 500, compresslevel: int = 9) -> None:
        self._inner = content
        self._minimum_size = minimum_size
        self._compresslevel = compresslevel

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        inner = self._inner
        body = inner.body
        if len(body) >= self._minimum_size:
            body = gzip.compress(body, compresslevel=self._compresslevel)
            inner._headers.set("content-encoding", "gzip")
            inner._headers.set("content-length", str(len(body)))
        await send(
            {
                "type": "http.response.start",
                "status": inner.status_code,
                "headers": inner._headers.raw,
            }
        )
        await send({"type": "http.response.body", "body": body, "more_body": False})
