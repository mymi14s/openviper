"""Authentication middleware: populates request.user from session or JWT."""

from __future__ import annotations

from typing import Any

from minova.auth.backends import get_user_by_id
from minova.auth.jwt import decode_access_token
from minova.auth.models import AnonymousUser
from minova.auth.sessions import get_user_from_session
from minova.middleware.base import ASGIApp, BaseMiddleware


class AuthenticationMiddleware(BaseMiddleware):
    """Identify the authenticated user from session cookie or Authorization header.

    Sets ``scope["user"]`` and ``scope["auth"]`` for downstream handlers.
    If no credentials are present, sets an anonymous user.

    Args:
        app: Next ASGI app.
    """

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return

        user, auth_info = await self._authenticate(scope)
        scope["user"] = user
        scope["auth"] = auth_info
        await self.app(scope, receive, send)

    async def _authenticate(self, scope: dict[str, Any]) -> tuple[Any, Any]:
        """Try session then JWT authentication.

        Returns:
            (user, auth_info) tuple.  user is AnonymousUser if not authenticated.
        """
        headers = dict(scope.get("headers", []))

        # 1. Try JWT Bearer token
        auth_header = headers.get(b"authorization", b"").decode("latin-1")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            try:
                payload = decode_access_token(token)
                user_id = payload.get("sub")
                if user_id:
                    user = await get_user_by_id(int(user_id))
                    if user and user.is_active:
                        return user, {"type": "jwt", "token": token}
            except Exception:
                pass

        # 2. Try session cookie
        cookie_header = headers.get(b"cookie", b"").decode("latin-1")
        if cookie_header:
            session_user = await get_user_from_session(cookie_header)
            if session_user:
                return session_user, {"type": "session"}

        return AnonymousUser(), {"type": "none"}
