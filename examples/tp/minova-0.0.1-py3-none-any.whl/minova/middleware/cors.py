"""CORS (Cross-Origin Resource Sharing) middleware."""

from __future__ import annotations

import fnmatch
from typing import Any

from minova.middleware.base import ASGIApp, BaseMiddleware


class CORSMiddleware(BaseMiddleware):
    """Handle Cross-Origin Resource Sharing headers.

    Args:
        app: Next ASGI app.
        allowed_origins: List of allowed origin strings. Supports wildcards.
        allow_credentials: Allow ``Authorization`` / cookies cross-origin.
        allowed_methods: Permitted HTTP methods.
        allowed_headers: Permitted request headers (``["*"]`` = all).
        expose_headers: Headers to expose to the browser.
        max_age: Preflight cache TTL in seconds.
    """

    def __init__(
        self,
        app: ASGIApp,
        allowed_origins: list[str] | None = None,
        allow_credentials: bool = True,
        allowed_methods: list[str] | None = None,
        allowed_headers: list[str] | None = None,
        expose_headers: list[str] | None = None,
        max_age: int = 600,
    ) -> None:
        super().__init__(app)
        self.allowed_origins = allowed_origins or ["*"]
        self.allow_credentials = allow_credentials
        self.allowed_methods = [m.upper() for m in (allowed_methods or ["*"])]
        self.allowed_headers = [h.lower() for h in (allowed_headers or ["*"])]
        self.expose_headers = expose_headers or []
        self.max_age = max_age
        self._allow_all_origins = "*" in self.allowed_origins
        self._allow_all_headers = "*" in self.allowed_headers

    def _origin_allowed(self, origin: str) -> bool:
        if self._allow_all_origins:
            return True
        return any(fnmatch.fnmatch(origin, pattern) for pattern in self.allowed_origins)

    def _build_headers(self, origin: str, is_preflight: bool) -> list[tuple[bytes, bytes]]:
        headers: list[tuple[bytes, bytes]] = []

        if self._origin_allowed(origin):
            headers.append((b"access-control-allow-origin", origin.encode("latin-1")))
        elif not self._allow_all_origins:
            return headers

        if self.allow_credentials:
            headers.append((b"access-control-allow-credentials", b"true"))

        if is_preflight:
            methods = ", ".join(
                self.allowed_methods
                if "*" not in self.allowed_methods
                else ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"]
            )
            headers.append((b"access-control-allow-methods", methods.encode("latin-1")))
            if self._allow_all_headers:
                headers.append((b"access-control-allow-headers", b"*"))
            else:
                headers.append(
                    (
                        b"access-control-allow-headers",
                        ", ".join(self.allowed_headers).encode("latin-1"),
                    )
                )
            headers.append((b"access-control-max-age", str(self.max_age).encode("latin-1")))

        if self.expose_headers:
            headers.append(
                (
                    b"access-control-expose-headers",
                    ", ".join(self.expose_headers).encode("latin-1"),
                )
            )

        return headers

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        origin = ""
        for name, value in scope.get("headers", []):
            if name == b"origin":
                origin = value.decode("latin-1")
                break

        if not origin:
            await self.app(scope, receive, send)
            return

        method = scope.get("method", "GET").upper()
        is_preflight = method == "OPTIONS"

        cors_headers = self._build_headers(origin, is_preflight)

        if is_preflight:
            # Respond immediately to preflight requests
            await send(
                {
                    "type": "http.response.start",
                    "status": 204,
                    "headers": cors_headers + [[b"content-length", b"0"]],
                }
            )
            await send({"type": "http.response.body", "body": b""})
            return

        async def send_with_cors(message: dict[str, Any]) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", [])) + cors_headers
                message = {**message, "headers": headers}
            await send(message)

        await self.app(scope, receive, send_with_cors)
