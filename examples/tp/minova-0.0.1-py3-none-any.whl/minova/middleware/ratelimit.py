"""Token-bucket / sliding-window rate limiting middleware and decorator."""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict, deque
from collections.abc import Callable
from functools import wraps
from typing import Any

from minova.conf import settings
from minova.exceptions import TooManyRequests
from minova.http.request import Request
from minova.http.response import JSONResponse
from minova.middleware.base import BaseMiddleware


class _SlidingWindowCounter:
    """In-process sliding window rate counter (per-key)."""

    def __init__(self, max_requests: int, window_seconds: float) -> None:
        self.max_requests = max_requests
        self.window = window_seconds
        self._buckets: dict[str, deque[float]] = defaultdict(deque)
        self._lock = asyncio.Lock()

    async def is_allowed(self, key: str) -> tuple[bool, int]:
        """Return (allowed, remaining) for *key*."""
        now = time.monotonic()
        cutoff = now - self.window
        async with self._lock:
            bucket = self._buckets[key]
            # Remove old entries
            while bucket and bucket[0] < cutoff:
                bucket.popleft()
            if len(bucket) >= self.max_requests:
                return False, 0
            bucket.append(now)
            return True, self.max_requests - len(bucket)


class RateLimitMiddleware(BaseMiddleware):
    """ASGI rate limiting middleware using a sliding window per remote IP.

    Settings (can also be passed directly)::

        RATE_LIMIT_REQUESTS = 100   # requests allowed per window
        RATE_LIMIT_WINDOW   = 60    # window size in seconds
        RATE_LIMIT_BY       = "ip"  # "ip" | "user" | "path"

    The middleware adds ``X-RateLimit-Limit``, ``X-RateLimit-Remaining``,
    and ``Retry-After`` headers to every response.
    """

    def __init__(
        self,
        app: Any,
        max_requests: int | None = None,
        window_seconds: float | None = None,
        key_func: Callable[[dict], str] | None = None,
    ) -> None:
        super().__init__(app)
        self.max_requests = (
            max_requests
            if max_requests is not None
            else getattr(settings, "RATE_LIMIT_REQUESTS", 100)
        )
        self.window_seconds = (
            window_seconds
            if window_seconds is not None
            else getattr(settings, "RATE_LIMIT_WINDOW", 60.0)
        )
        self.counter = _SlidingWindowCounter(self.max_requests, self.window_seconds)
        self._key_func = key_func or self._default_key

    @staticmethod
    def _default_key(scope: dict) -> str:
        """Key = client IP address."""
        client = scope.get("client")
        if client:
            return client[0]
        headers = dict(scope.get("headers", []))
        forwarded_for = headers.get(b"x-forwarded-for", b"").decode()
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
        return "unknown"

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        if scope["type"] not in ("http", "https"):
            await self.app(scope, receive, send)
            return

        key = self._key_func(scope)
        allowed, remaining = await self.counter.is_allowed(key)

        if not allowed:
            response = JSONResponse(
                {
                    "detail": "Too many requests",
                    "retry_after": int(self.window_seconds),
                },
                status_code=429,
                headers={
                    "X-RateLimit-Limit": str(self.max_requests),
                    "X-RateLimit-Remaining": "0",
                    "Retry-After": str(int(self.window_seconds)),
                },
            )
            await response(scope, receive, send)
            return

        rl_headers = {
            "X-RateLimit-Limit": str(self.max_requests),
            "X-RateLimit-Remaining": str(remaining),
        }

        # Inject headers into the response
        async def send_with_headers(message: dict) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                for k, v in rl_headers.items():
                    headers.append([k.lower().encode(), v.encode()])
                message = {**message, "headers": headers}
            await send(message)

        await self.app(scope, receive, send_with_headers)


# ---------------------------------------------------------------------------
# View decorator
# ---------------------------------------------------------------------------


def rate_limit(max_requests: int = 60, window_seconds: float = 60.0) -> Callable:
    """Decorator to apply per-view rate limiting based on client IP.

    Usage::

        @app.get("/expensive")
        @rate_limit(max_requests=10, window=60)
        async def expensive_view(request: Request):
            ...
    """
    counter = _SlidingWindowCounter(max_requests, window_seconds)

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            request: Request | None = None
            for arg in args:
                if isinstance(arg, Request):
                    request = arg
                    break
            if request is None:
                request = kwargs.get("request")

            if request is not None:
                key = (request.client or ("unknown", 0))[0]
                allowed, _remaining = await counter.is_allowed(key)
                if not allowed:
                    raise TooManyRequests(
                        detail=f"Rate limit exceeded: {max_requests} requests per {window_seconds}s"
                    )
            return await func(*args, **kwargs)

        return wrapper

    return decorator
