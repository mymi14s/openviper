"""Security middleware: HSTS, X-Content-Type-Options, X-Frame-Options, etc."""

from __future__ import annotations

from typing import Any

from minova.conf import settings
from minova.middleware.base import ASGIApp, BaseMiddleware


class SecurityMiddleware(BaseMiddleware):
    """Adds HTTP security headers to all responses.

    Headers added:

    - ``X-Content-Type-Options: nosniff``
    - ``X-Frame-Options: DENY`` (configurable)
    - ``Referrer-Policy: strict-origin-when-cross-origin``
    - ``Strict-Transport-Security`` (when ``hsts_seconds > 0``)
    - Redirect HTTP → HTTPS when ``ssl_redirect=True``

    Args:
        app: Next ASGI app.
        ssl_redirect: Redirect all HTTP requests to HTTPS.
        hsts_seconds: HSTS max-age. ``0`` disables the header.
        hsts_include_subdomains: Include subdomains in HSTS.
        hsts_preload: Add preload directive to HSTS.
        x_frame_options: ``DENY``, ``SAMEORIGIN``, or empty to disable.
        content_type_nosniff: Add ``X-Content-Type-Options: nosniff``.
        xss_filter: Add ``X-XSS-Protection: 1; mode=block``.
        csp: Optional Content-Security-Policy dictionary or string.
    """

    def __init__(
        self,
        app: ASGIApp,
        ssl_redirect: bool = False,
        hsts_seconds: int = 0,
        hsts_include_subdomains: bool = False,
        hsts_preload: bool = False,
        x_frame_options: str = "DENY",
        content_type_nosniff: bool = True,
        xss_filter: bool | None = None,
        csp: dict[str, Any] | str | None = None,
    ) -> None:
        super().__init__(app)
        self.ssl_redirect = ssl_redirect
        self.hsts_seconds = hsts_seconds
        self.hsts_include_subdomains = hsts_include_subdomains
        self.hsts_preload = hsts_preload
        self.x_frame_options = x_frame_options
        self.content_type_nosniff = content_type_nosniff
        self.xss_filter = (
            xss_filter
            if xss_filter is not None
            else getattr(settings, "SECURE_BROWSER_XSS_FILTER", True)
        )
        self.csp = (
            csp if csp is not None else getattr(settings, "SECURE_CONTENT_SECURITY_POLICY", None)
        )

        # Pre-build fixed security headers
        self._fixed_headers: list[tuple[bytes, bytes]] = []
        if content_type_nosniff:
            self._fixed_headers.append((b"x-content-type-options", b"nosniff"))
        if x_frame_options:
            self._fixed_headers.append((b"x-frame-options", x_frame_options.encode("latin-1")))
        self._fixed_headers.append((b"referrer-policy", b"strict-origin-when-cross-origin"))
        if hsts_seconds > 0:
            hsts = f"max-age={hsts_seconds}"
            if hsts_include_subdomains:
                hsts += "; includeSubDomains"
            if hsts_preload:
                hsts += "; preload"
            self._fixed_headers.append((b"strict-transport-security", hsts.encode("latin-1")))

        if self.xss_filter:
            self._fixed_headers.append((b"x-xss-protection", b"1; mode=block"))

        if self.csp:
            if isinstance(self.csp, dict):
                csp_str = "; ".join(
                    [
                        f"{k} {' '.join(v) if isinstance(v, list) else v}"
                        for k, v in self.csp.items()
                    ]
                )
            else:
                csp_str = str(self.csp)
            self._fixed_headers.append((b"content-security-policy", csp_str.encode("latin-1")))

    @staticmethod
    def _get_host(scope: dict[str, Any]) -> str:
        """Extract the host from the request scope headers."""
        for name, value in scope.get("headers", []):
            if name == b"host":
                # Strip port number if present (e.g. "localhost:8000" -> "localhost")
                host = value.decode("latin-1")
                if ":" in host:
                    host = host.rsplit(":", 1)[0]
                return host
        # Fallback: use server tuple from scope
        server = scope.get("server")
        if server:
            return server[0]
        return ""

    def _is_host_allowed(self, host: str) -> bool:
        """Check if the given host is in ALLOWED_HOSTS."""

        allowed_hosts: list[str] = getattr(settings, "ALLOWED_HOSTS", [])
        if not allowed_hosts:
            return False

        host_lower = host.lower()
        for pattern in allowed_hosts:
            pattern_lower = pattern.lower()
            if pattern_lower == "*":
                return True
            # Support wildcard subdomains like ".example.com"
            if pattern_lower.startswith(".") and (
                host_lower.endswith(pattern_lower) or host_lower == pattern_lower[1:]
            ):
                return True
            if host_lower == pattern_lower:
                return True
        return False

    async def _send_400(self, send: Any, host: str) -> None:
        """Send a 400 Bad Request response for disallowed hosts."""
        body = f"Invalid HTTP_HOST header: '{host}'. The host is not allowed.".encode()
        await send(
            {
                "type": "http.response.start",
                "status": 400,
                "headers": [
                    [b"content-type", b"text/plain; charset=utf-8"],
                    [b"content-length", str(len(body)).encode("latin-1")],
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        # ── ALLOWED_HOSTS check ──────────────────────────────────────────
        host = self._get_host(scope)
        if not self._is_host_allowed(host):
            await self._send_400(send, host)
            return

        if self.ssl_redirect and scope.get("scheme") == "http":
            # Build redirect URL
            raw_host = "localhost"
            for name, value in scope.get("headers", []):
                if name == b"host":
                    raw_host = value.decode("latin-1")
                    break
            path = scope.get("path", "/")
            qs = scope.get("query_string", b"")
            url = f"https://{raw_host}{path}"
            if qs:
                url += f"?{qs.decode('latin-1')}"

            await send(
                {
                    "type": "http.response.start",
                    "status": 301,
                    "headers": [
                        [b"location", url.encode("latin-1")],
                        [b"content-length", b"0"],
                    ],
                }
            )
            await send({"type": "http.response.body", "body": b""})
            return

        fixed = self._fixed_headers

        async def send_with_security(message: dict[str, Any]) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.extend(fixed)
                message = {**message, "headers": headers}
            await send(message)

        await self.app(scope, receive, send_with_security)
