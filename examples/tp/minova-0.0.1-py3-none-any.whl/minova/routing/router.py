"""URL routing engine for MiNova.

Supports:
  - Literal path segments: ``/users``
  - String parameters: ``/users/{id}``
  - Typed parameters: ``/users/{id:int}``, ``/files/{path:path}``
  - HTTP method routing
  - Sub-routers (blueprints) with ``include()``
  - Middleware attachment per-router
"""

from __future__ import annotations

import re
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from minova.exceptions import MethodNotAllowed, NotFound

if TYPE_CHECKING:
    from minova.http.request import Request  # noqa: F401
    from minova.http.response import Response  # noqa: F401

# ── Type aliases ─────────────────────────────────────────────────────────────

Handler = Callable[..., Awaitable[Any]]
Middleware = Callable[[Any, Any], Awaitable[Any]]

# ── Path converters ───────────────────────────────────────────────────────────

CONVERTERS: dict[str, tuple[str, Callable[[str], Any]]] = {
    "str": (r"[^/]+", str),
    "int": (r"[0-9]+", int),
    "float": (r"[0-9]+(?:\.[0-9]+)?", float),
    "path": (r".+", str),
    "uuid": (r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", str),
    "slug": (r"[-a-zA-Z0-9_]+", str),
}


def _compile_path(path: str) -> tuple[re.Pattern[str], dict[str, Callable[[str], Any]]]:
    """Convert a path template like ``/users/{id:int}`` to a compiled regex."""
    pattern = "^"
    param_converters: dict[str, Callable[[str], Any]] = {}
    last_end = 0
    for m in re.finditer(r"\{([a-zA-Z_][a-zA-Z0-9_]*)(?::([a-zA-Z]+))?\}", path):
        pattern += re.escape(path[last_end : m.start()])
        name = m.group(1)
        conv_name = m.group(2) or "str"
        regex, conv = CONVERTERS.get(conv_name, CONVERTERS["str"])
        pattern += f"(?P<{name}>{regex})"
        param_converters[name] = conv
        last_end = m.end()
    pattern += re.escape(path[last_end:]) + "$"
    return re.compile(pattern), param_converters


# ── Route ─────────────────────────────────────────────────────────────────────


@dataclass
class Route:
    """A single registered route.

    Attributes:
        path: URL path template.
        methods: Allowed HTTP methods.
        handler: Async callable that handles the request.
        name: Optional name for reverse URL generation.
        middlewares: Per-route middleware stack.
    """

    path: str
    methods: set[str]
    handler: Handler
    name: str | None = None
    middlewares: list[Middleware] = field(default_factory=list)

    # Compiled
    _regex: re.Pattern[str] = field(init=False, repr=False)
    _converters: dict[str, Callable[[str], Any]] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._regex, self._converters = _compile_path(self.path)
        self.methods = {m.upper() for m in self.methods}

    def match(self, path: str) -> dict[str, Any] | None:
        """Return path params dict if path matches, else None."""
        m = self._regex.match(path)
        if m is None:
            return None
        params: dict[str, Any] = {}
        for name, conv in self._converters.items():
            params[name] = conv(m.group(name))
        return params

    def __repr__(self) -> str:
        return (
            f"Route({self.path!r}, methods={sorted(self.methods)}, "
            f"handler={self.handler.__name__!r})"
        )


# ── Router ────────────────────────────────────────────────────────────────────


class Router:
    """URL router that collects routes and resolves requests.

    Supports route groups (sub-routers) via ``include()``.

    Example:
        >>> router = Router(prefix="/api")
        >>> @router.get("/users")
        ... async def list_users(request): ...
    """

    def __init__(self, prefix: str = "", middlewares: list[Middleware] | None = None) -> None:
        self.prefix = prefix.rstrip("/")
        self.middlewares: list[Middleware] = middlewares or []
        self._routes: list[Route] = []
        self._sub_routers: list[Router] = []

    # ── Route registration ─────────────────────────────────────────────────

    def route(
        self,
        path: str,
        methods: list[str],
        name: str | None = None,
        middlewares: list[Middleware] | None = None,
    ) -> Callable[[Handler], Handler]:
        """Decorator to register a handler for a path and methods."""

        def decorator(func: Handler) -> Handler:
            full_path = self.prefix + path
            self._routes.append(
                Route(
                    path=full_path,
                    methods=set(methods),
                    handler=func,
                    name=name or func.__name__,
                    middlewares=middlewares or [],
                )
            )
            return func

        return decorator

    def get(self, path: str, **kwargs: Any) -> Callable[[Handler], Handler]:
        return self.route(path, ["GET", "HEAD"], **kwargs)

    def post(self, path: str, **kwargs: Any) -> Callable[[Handler], Handler]:
        return self.route(path, ["POST"], **kwargs)

    def put(self, path: str, **kwargs: Any) -> Callable[[Handler], Handler]:
        return self.route(path, ["PUT"], **kwargs)

    def patch(self, path: str, **kwargs: Any) -> Callable[[Handler], Handler]:
        return self.route(path, ["PATCH"], **kwargs)

    def delete(self, path: str, **kwargs: Any) -> Callable[[Handler], Handler]:
        return self.route(path, ["DELETE"], **kwargs)

    def options(self, path: str, **kwargs: Any) -> Callable[[Handler], Handler]:
        return self.route(path, ["OPTIONS"], **kwargs)

    def any(self, path: str, **kwargs: Any) -> Callable[[Handler], Handler]:
        return self.route(
            path, ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"], **kwargs
        )

    def add(
        self,
        path: str,
        handler: Handler,
        methods: list[str] | None = None,
        namespace: str | None = None,
        middlewares: list[Middleware] | None = None,
    ) -> None:
        """Add a route directly without using decorators.

        Args:
            path: URL path pattern
            handler: Handler function
            methods: HTTP methods (default: ["GET"])
            namespace: Route name (default: handler.__name__)
            middlewares: Route-specific middlewares
        """
        methods = methods or ["GET"]
        name = namespace or handler.__name__
        full_path = self.prefix + path
        self._routes.append(
            Route(
                path=full_path,
                methods=set(methods),
                handler=handler,
                name=name,
                middlewares=middlewares or [],
            )
        )

    # ── Sub-routers ────────────────────────────────────────────────────────

    def include_router(self, router: Router) -> None:
        """Mount a sub-router, prefixing all its routes with this router's prefix."""
        # Adjust prefix of sub-router routes
        adjusted = Router(
            prefix=self.prefix + router.prefix,
            middlewares=self.middlewares + router.middlewares,
        )
        adjusted._routes = [
            Route(
                path=self.prefix + route.path,
                methods=route.methods,
                handler=route.handler,
                name=route.name,
                middlewares=route.middlewares,
            )
            for route in router.routes
        ]
        for sub in router._sub_routers:
            adjusted._sub_routers.append(sub)
        self._sub_routers.append(adjusted)

    # ── Route resolution ───────────────────────────────────────────────────

    @property
    def routes(self) -> list[Route]:
        """All routes including sub-router routes, flattened."""
        all_routes: list[Route] = list(self._routes)
        for sub in self._sub_routers:
            all_routes.extend(sub.routes)
        return all_routes

    def resolve(self, method: str, path: str) -> tuple[Route, dict[str, Any]]:
        """Find the matching route for a path and method.

        Returns:
            (route, path_params) tuple.

        Raises:
            NotFound: No route matched the path.
            MethodNotAllowed: Path matched but method not allowed.
        """
        method = method.upper()
        matched_route: Route | None = None
        allowed_methods: set[str] = set()

        # Build candidate paths: always try the original path first, then
        # a slash-normalised alternative so that routes registered with a
        # trailing slash are reachable without one and vice-versa.
        #   /home/  → also try /home
        #   /admin  → also try /admin/
        #   /       → no alternative (root must stay as-is)
        candidates: list[str] = [path]
        if path == "" or path == "/":
            candidates = ["/", ""]
        else:
            if path.endswith("/"):
                candidates.append(path.rstrip("/"))
            else:
                candidates.append(path + "/")

        for candidate in candidates:
            for route in self.routes:
                params = route.match(candidate)
                if params is not None:
                    allowed_methods.update(route.methods)
                    if method in route.methods:
                        matched_route = route
                        break
            if matched_route is not None:
                break

        if matched_route is None:
            # Collect allowed methods across all candidates for a better 405
            if not allowed_methods:
                for candidate in candidates:
                    for route in self.routes:
                        if route.match(candidate) is not None:
                            allowed_methods.update(route.methods)
            if allowed_methods:
                raise MethodNotAllowed(sorted(allowed_methods))
            raise NotFound(f"No route found for '{path}'")

        return matched_route, params  # type: ignore[return-value]

    def url_for(self, name: str, **path_params: Any) -> str:
        """Reverse-resolve a URL by route name.

        Args:
            name: Route name as registered.
            **path_params: Values to fill in path parameters.

        Returns:
            URL string.

        Raises:
            KeyError: Route name not found.
        """
        for route in self.routes:
            if route.name == name:
                path = route.path
                for key, value in path_params.items():
                    # Replace {key} and {key:type}
                    path = re.sub(rf"\{{  {key}(?::[a-zA-Z]+)?  \}}", str(value), path, flags=re.X)
                return path
        raise KeyError(f"No route named '{name}'")

    def __repr__(self) -> str:
        return f"Router(prefix={self.prefix!r}, routes={len(self.routes)})"


# ── Convenience helpers ───────────────────────────────────────────────────────


def include(router: Router, prefix: str = "") -> Router:
    """Helper to include a sub-router with an optional additional prefix.

    Creates a new router whose route paths are all prefixed with the given
    ``prefix``.  The original router is left unchanged.

    Example:
        >>> from myapp.routes import router as user_router
        >>> app.include_router(include(user_router, prefix="/api/v1"))
    """
    if prefix:
        adjusted = Router(prefix=prefix + router.prefix)
        # Re-create each route with the extra prefix prepended to its path.
        # (Route paths already contain the original router prefix.)
        adjusted._routes = [
            Route(
                path=prefix + route.path,
                methods=route.methods,
                handler=route.handler,
                name=route.name,
                middlewares=route.middlewares,
            )
            for route in router._routes
        ]
        # Recursively wrap sub-routers with the same prefix.
        adjusted._sub_routers = [include(sub, prefix=prefix) for sub in router._sub_routers]
        return adjusted
    return router
