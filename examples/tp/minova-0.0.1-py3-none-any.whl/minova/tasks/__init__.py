"""Background task definitions using Dramatiq.

Example:
    .. code-block:: python

        from minova.tasks import task

        @task(queue_name="default", max_retries=3)
        def send_welcome_email(user_id: int) -> None:
            user = User.objects.get(id=user_id)
            send_email(user.email, "Welcome!", ...)

        # Enqueue
        send_welcome_email.delay(user_id=42)
"""

from __future__ import annotations

from minova.tasks.broker import get_broker, setup_broker
from minova.tasks.decorators import task

# Auto-initialize the broker on import
setup_broker()

__all__ = ["task", "get_broker", "setup_broker"]
