"""Broker configuration and factory logic for background tasks.

Supported brokers (configured via ``TASKS.BACKEND`` in settings):

* ``"redis"``    — `dramatiq.brokers.redis.RedisBroker`
* ``"rabbitmq"`` — `dramatiq.brokers.rabbitmq.RabbitmqBroker`
* ``"database"`` — `minova.tasks.db_broker.DatabaseBroker` (no external dep)
* ``"stub"``     — `dramatiq.brokers.stub.StubBroker` (testing only)

Supported result backends (configured via ``TASKS.RESULT_BACKEND`` in settings):

* ``"redis"``       — `dramatiq_results.backends.RedisBackend`
* ``"rabbitmq"``    — `dramatiq_results.backends.RabbitmqBackend`
* ``"memcached"``   — `dramatiq_results.backends.MemcachedBackend`
* ``"stub"``        — `dramatiq_results.backends.StubBackend` (testing only)

Example settings::

    TASKS = {
        "BACKEND": "redis",
        "URL": "redis://localhost:6379/0",
        "RESULT_BACKEND": "redis",
        "RESULT_BACKEND_URL": "redis://localhost:6379/1",
        "RESULT_TTL": 86_400_000,  # milliseconds; default 24 h
    }
"""

from __future__ import annotations

import logging
from typing import Any

import dramatiq
import dramatiq.brokers.rabbitmq
import dramatiq.brokers.redis
import dramatiq.brokers.stub
from dramatiq.middleware.asyncio import AsyncIO

# dramatiq.results — ships with dramatiq itself
from dramatiq.results import Results

from minova.conf import settings
from minova.tasks.db_broker import DatabaseBroker

# Optional: dramatiq_results backends (pip install dramatiq[results])
try:
    from dramatiq_results.backends import (
        MemcachedBackend,
        RabbitmqBackend,
        RedisBackend,
        StubBackend,
    )

    _RESULTS_AVAILABLE = True
except ImportError:
    RedisBackend = RabbitmqBackend = MemcachedBackend = StubBackend = None  # type: ignore[assignment, misc]
    _RESULTS_AVAILABLE = False

logger = logging.getLogger("minova.tasks")

_BROKER: Any = None
_RESULT_BACKEND: Any = None


# ── Broker factory ────────────────────────────────────────────────────────────


def _build_redis_broker(task_settings: dict[str, Any]) -> Any:
    """Instantiate a RedisBroker from task settings."""
    url = task_settings.get("URL", "redis://localhost:6379/0")
    try:
        return dramatiq.brokers.redis.RedisBroker(url=url)
    except Exception as exc:
        logger.warning(
            "Could not connect to Redis broker (%s): %s. Falling back to StubBroker.", url, exc
        )
        return dramatiq.brokers.stub.StubBroker()


def _build_rabbitmq_broker(task_settings: dict[str, Any]) -> Any:
    """Instantiate a RabbitmqBroker from task settings."""
    url = task_settings.get("URL", "amqp://guest:guest@localhost:5672/")
    try:
        return dramatiq.brokers.rabbitmq.RabbitmqBroker(url=url)
    except Exception as exc:
        logger.warning(
            "Could not connect to RabbitMQ broker (%s): %s. Falling back to StubBroker.", url, exc
        )
        return dramatiq.brokers.stub.StubBroker()


def _build_database_broker() -> Any:
    """Instantiate the database-backed broker."""
    try:
        return DatabaseBroker()
    except Exception as exc:
        logger.warning("Could not initialize DatabaseBroker: %s. Falling back to StubBroker.", exc)
        return dramatiq.brokers.stub.StubBroker()


def setup_broker() -> Any:
    """Read settings and initialize the configured Dramatiq broker.

    The broker is cached as a module-level singleton — subsequent calls return
    the same instance without re-reading settings.

    Returns:
        The configured Dramatiq broker instance.
    """
    global _BROKER
    if _BROKER is not None:
        return _BROKER

    try:
        task_settings: dict[str, Any] = getattr(settings, "TASKS", {})
        backend: str = task_settings.get("BACKEND", "redis")
    except Exception:
        backend = "stub"
        task_settings = {}

    backend_map = {
        "redis": lambda: _build_redis_broker(task_settings),
        "rabbitmq": lambda: _build_rabbitmq_broker(task_settings),
        "database": _build_database_broker,
        "stub": dramatiq.brokers.stub.StubBroker,
    }

    builder = backend_map.get(backend)
    if builder is None:
        logger.warning("Unknown task backend '%s'. Using StubBroker.", backend)
        broker = dramatiq.brokers.stub.StubBroker()
    else:
        broker = builder()

    # AsyncIO middleware enables `async def` task functions
    broker.add_middleware(AsyncIO())

    # Attach result backend if configured
    result_backend = setup_result_backend(task_settings)
    if result_backend is not None:
        broker.add_middleware(Results(backend=result_backend))
        logger.info("Result backend attached: %s", type(result_backend).__name__)

    _BROKER = broker
    dramatiq.set_broker(broker)
    logger.info("Dramatiq broker initialised: %s (backend=%s)", type(broker).__name__, backend)
    return broker


# ── Result backend factory ────────────────────────────────────────────────────


def _build_redis_result_backend(task_settings: dict[str, Any]) -> Any:
    """Instantiate a Redis result backend."""
    url = task_settings.get(
        "RESULT_BACKEND_URL", task_settings.get("URL", "redis://localhost:6379/1")
    )
    ttl = task_settings.get("RESULT_TTL", 86_400_000)
    return RedisBackend(url=url, result_ttl=ttl)


def _build_rabbitmq_result_backend(task_settings: dict[str, Any]) -> Any:
    """Instantiate a RabbitMQ result backend."""
    url = task_settings.get(
        "RESULT_BACKEND_URL", task_settings.get("URL", "amqp://guest:guest@localhost:5672/")
    )
    ttl = task_settings.get("RESULT_TTL", 86_400_000)
    return RabbitmqBackend(url=url, result_ttl=ttl)


def _build_memcached_result_backend(task_settings: dict[str, Any]) -> Any:
    """Instantiate a Memcached result backend."""
    servers = task_settings.get("RESULT_BACKEND_SERVERS", ["localhost:11211"])
    ttl = task_settings.get("RESULT_TTL", 86_400_000)
    return MemcachedBackend(servers=servers, result_ttl=ttl)


def setup_result_backend(task_settings: dict[str, Any] | None = None) -> Any:
    """Instantiate the configured result backend, or ``None`` if not configured.

    Args:
        task_settings: The ``TASKS`` dict from settings.  When ``None``, it is
            read from ``settings.TASKS`` directly.

    Returns:
        A ``dramatiq_results`` backend instance, or ``None`` if no
        ``RESULT_BACKEND`` key is present in settings.
    """
    global _RESULT_BACKEND
    if _RESULT_BACKEND is not None:
        return _RESULT_BACKEND

    if task_settings is None:
        try:
            task_settings = getattr(settings, "TASKS", {})
        except Exception:
            return None

    backend_name: str | None = task_settings.get("RESULT_BACKEND")
    if not backend_name:
        return None

    backend_map = {
        "redis": lambda: _build_redis_result_backend(task_settings),
        "rabbitmq": lambda: _build_rabbitmq_result_backend(task_settings),
        "memcached": lambda: _build_memcached_result_backend(task_settings),
        "stub": _build_stub_result_backend,
    }

    builder = backend_map.get(backend_name)
    if builder is None:
        logger.warning("Unknown result backend '%s'. Results will not be stored.", backend_name)
        return None

    try:
        _RESULT_BACKEND = builder()
        return _RESULT_BACKEND
    except Exception as exc:
        logger.warning("Could not initialise result backend '%s': %s.", backend_name, exc)
        return None


def _build_stub_result_backend() -> Any:
    """Instantiate the in-memory stub result backend (for testing)."""
    return StubBackend()


# ── Convenience accessors ─────────────────────────────────────────────────────


def get_broker() -> Any:
    """Return the currently configured broker, initialising it if necessary."""
    return setup_broker()


def get_result_backend() -> Any:
    """Return the currently configured result backend (may be ``None``)."""
    return _RESULT_BACKEND


def reset_broker() -> None:
    """Reset the broker singleton.  Primarily useful in tests."""
    global _BROKER, _RESULT_BACKEND
    _BROKER = None
    _RESULT_BACKEND = None
