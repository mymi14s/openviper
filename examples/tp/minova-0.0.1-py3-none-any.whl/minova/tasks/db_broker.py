"""Database-backed broker implementation for Dramatiq."""

from __future__ import annotations

import datetime
import logging
import time
from collections.abc import Iterable

import sqlalchemy as sa
from dramatiq.broker import Broker, Consumer, MessageProxy
from dramatiq.message import Message

from minova.conf import settings
from minova.utils import timezone

logger = logging.getLogger("minova.tasks")


class DatabaseBroker(Broker):
    """A Dramatiq broker that stores messages in a database table."""

    def __init__(self, *, middleware=None):
        super().__init__(middleware=middleware)
        self._engine = self._get_sync_engine()
        self._metadata = sa.MetaData()
        self._table = sa.Table(
            "minova_tasks",
            self._metadata,
            sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
            sa.Column("queue_name", sa.String(100), nullable=False),
            sa.Column("message", sa.LargeBinary, nullable=False),
            sa.Column("status", sa.String(20), default="pending"),
            sa.Column("eta", sa.DateTime, nullable=True),
            sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        )

    def _get_sync_engine(self) -> sa.engine.Engine:
        url = settings.DATABASE_URL
        # Ensure it is a sync URL
        sync_url = url
        replacements = {
            "sqlite+aiosqlite://": "sqlite://",
            "postgresql+asyncpg://": "postgresql://",
            "mysql+aiomysql://": "mysql://",
        }
        for old, new in replacements.items():
            if sync_url.startswith(old):
                sync_url = new + sync_url[len(old) :]
                break

        return sa.create_engine(sync_url)

    def declare_queue(self, queue_name: str) -> None:
        """Declare a queue by adding it to the set of known queues."""
        self.queues[queue_name] = True

    def enqueue(self, message: Message, delay: int | None = None) -> Message:
        """Store the message in the database."""
        eta: datetime.datetime | None = None

        # Determine ETA from delay or message options
        delay_ms = delay or message.options.get("delay")
        eta_ms = message.options.get("eta")

        if delay_ms:
            eta = timezone.now() + datetime.timedelta(milliseconds=delay_ms)
        elif eta_ms:
            eta = datetime.datetime.fromtimestamp(eta_ms / 1000.0)

        with self._engine.connect() as conn:
            conn.execute(
                self._table.insert().values(
                    queue_name=message.queue_name,
                    message=message.encode(),
                    status="pending",
                    eta=eta,
                )
            )
            conn.commit()
        logger.debug(
            "Enqueued message %s to queue %s (eta: %s)", message.message_id, message.queue_name, eta
        )
        return message

    def consume(
        self, queue_name: str, prefetch: int = 1, timeout: int = 5000
    ) -> Iterable[MessageProxy | None]:
        return _DatabaseConsumer(self, queue_name, prefetch, timeout)

    def get_declared_queues(self) -> set[str]:
        # For simplicity, we assume queues are dynamic
        return {"default"}


class _DatabaseConsumer(Consumer):
    def __init__(self, broker: DatabaseBroker, queue_name: str, prefetch: int, timeout: int):
        self.broker = broker
        self.queue_name = queue_name
        self.prefetch = prefetch
        self.timeout = timeout

    def __next__(self) -> MessageProxy | None:
        """Poll the database for the next pending message."""
        start_time = time.monotonic()
        while True:
            with self.broker._engine.begin() as conn:
                now = timezone.now()
                # Find a pending task that is due
                select_stmt = (
                    sa.select(self.broker._table.c.id, self.broker._table.c.message)
                    .where(
                        sa.and_(
                            self.broker._table.c.queue_name == self.queue_name,
                            self.broker._table.c.status == "pending",
                            sa.or_(
                                self.broker._table.c.eta.is_(None), self.broker._table.c.eta <= now
                            ),
                        )
                    )
                    .order_by(self.broker._table.c.created_at.asc())
                    .limit(1)
                )

                row = conn.execute(select_stmt).fetchone()
                if row:
                    task_id, message_data = row
                    conn.execute(
                        self.broker._table.update()
                        .where(self.broker._table.c.id == task_id)
                        .values(status="processing")
                    )
                    message = Message.decode(message_data)
                    # We store the DB ID in options for acking
                    message = message.copy(options={"db_task_id": task_id})
                    logger.info(
                        "Found task %d for queue %s. Status -> processing.",
                        task_id,
                        self.queue_name,
                    )
                    return MessageProxy(message)

            # If we reached the timeout, return None
            if (time.monotonic() - start_time) * 1000 >= self.timeout:
                return None

            time.sleep(0.5)

    def ack(self, message: MessageProxy) -> None:
        """Mark the task as completed."""
        db_task_id = message.options.get("db_task_id")
        if db_task_id:
            with self.broker._engine.begin() as conn:
                conn.execute(
                    self.broker._table.update()
                    .where(self.broker._table.c.id == db_task_id)
                    .values(status="completed")
                )
            logger.info("Task %d marked as completed.", db_task_id)

    def nack(self, message: MessageProxy) -> None:
        """Mark the task as failed."""
        db_task_id = message.options.get("db_task_id")
        if db_task_id:
            with self.broker._engine.begin() as conn:
                conn.execute(
                    self.broker._table.update()
                    .where(self.broker._table.c.id == db_task_id)
                    .values(status="failed")
                )

    def requeue(self, messages: Iterable[MessageProxy]) -> None:
        """Mark the tasks as pending again."""
        db_task_ids = [m.options.get("db_task_id") for m in messages if m.options.get("db_task_id")]
        if db_task_ids:
            with self.broker._engine.begin() as conn:
                conn.execute(
                    self.broker._table.update()
                    .where(self.broker._table.c.id.in_(db_task_ids))
                    .values(status="pending")
                )
