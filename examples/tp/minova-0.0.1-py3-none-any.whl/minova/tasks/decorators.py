"""Task decorators for registering background tasks."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

import dramatiq

from minova.tasks.broker import setup_broker

logger = logging.getLogger("minova.tasks")


def task(
    queue_name: str = "default",
    priority: int = 0,
    max_retries: int = 3,
    min_backoff: int = 15000,
    max_backoff: int = 300000,
    time_limit: int | None = None,
) -> Callable:
    """Decorator to register a function as a Dramatiq background task.

    Args:
        queue_name: Queue to route the task to.
        priority: Priority within the queue (higher = more urgent).
        max_retries: Maximum number of retry attempts.
        min_backoff: Minimum retry backoff in milliseconds.
        max_backoff: Maximum retry backoff in milliseconds.
        time_limit: Maximum execution time in milliseconds.
    """

    def decorator(func: Callable) -> Any:
        # Ensure broker is set up
        setup_broker()

        actor_kwargs: dict[str, Any] = {
            "queue_name": queue_name,
            "priority": priority,
            "actor_name": f"{func.__module__}.{func.__name__}",
        }
        if time_limit:
            actor_kwargs["time_limit"] = time_limit

        actor = dramatiq.actor(func, **actor_kwargs)

        # Add .delay() shortcut
        actor.delay = actor.send

        return actor

    return decorator
