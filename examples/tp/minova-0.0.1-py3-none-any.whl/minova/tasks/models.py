"""Database models for background tasks."""

from __future__ import annotations

from minova.db import fields
from minova.db.models import Model


class TaskRecord(Model):
    """Stores a serialized Dramatiq message in the database."""

    class Meta:
        table_name = "minova_tasks"

    id = fields.IntegerField(primary_key=True, auto_increment=True)
    queue_name = fields.CharField(max_length=100)
    message = fields.BinaryField()
    status = fields.CharField(max_length=20, default="pending")
    eta = fields.DateTimeField(null=True)
    created_at = fields.DateTimeField(auto_now_add=True)

    def __repr__(self) -> str:
        return f"<TaskRecord id={self.id} queue={self.queue_name} status={self.status}>"
