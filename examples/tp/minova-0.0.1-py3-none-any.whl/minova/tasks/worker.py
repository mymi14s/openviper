"""Worker logic for background tasks."""

from __future__ import annotations

import importlib
import logging
import os
import signal
import sys
import time

from dramatiq.worker import Worker

from minova.conf import settings
from minova.core.app_resolver import AppResolver
from minova.tasks.broker import setup_broker

logger = logging.getLogger("minova.tasks")


def _discover_tasks() -> None:
    """Auto-discover and import modules in all INSTALLED_APPS to register tasks."""
    resolver = AppResolver()
    discovered = []
    for app_name in getattr(settings, "INSTALLED_APPS", []):
        app_path, found = resolver.resolve_app(app_name)
        if found and app_path:
            for root, dirs, files in os.walk(app_path):
                if "migrations" in dirs:
                    dirs.remove("migrations")
                if "tests" in dirs:
                    dirs.remove("tests")
                for file in files:
                    if file.endswith(".py") and file != "__init__.py":
                        rel_path = os.path.relpath(os.path.join(root, file), app_path)
                        module_subpath = rel_path[:-3].replace(os.sep, ".")
                        module_name = f"{app_name}.{module_subpath}"
                        try:
                            importlib.import_module(module_name)
                            discovered.append(module_name)
                        except Exception as e:
                            logger.warning("Could not import module %s: %s", module_name, e)

    if discovered:
        logger.info("Discovered and imported %d task modules.", len(discovered))
        logger.debug("Modules: %s", ", ".join(discovered))


def run_worker(
    processes: int = 1,
    threads: int = 8,
    queues: list[str] | None = None,
) -> None:
    """Start a Dramatiq worker for the configured broker."""
    # Discover tasks first so actors are registered
    _discover_tasks()

    broker = setup_broker()

    worker = Worker(
        broker,
        worker_threads=threads,
        queues=set(queues) if queues else None,
    )

    logger.info(
        "Background worker started. Monitoring queues: %s",
        ", ".join(queues) if queues else "all defined queues",
    )
    logger.info("Press Ctrl+C to stop.")

    def shutdown(signum, frame):
        logger.info("Shutdown signal received. Stopping worker...")
        worker.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    worker.start()
    # worker.start() is blocking if no processes are used?
    # Actually dramatiq.Worker.start() starts threads/processes and returns.
    # We need to wait or join.
    try:
        while True:
            signal.pause()
    except (KeyboardInterrupt, SystemExit):
        worker.stop()
    except AttributeError:
        # signal.pause() not available on Windows
        while True:
            time.sleep(1)
