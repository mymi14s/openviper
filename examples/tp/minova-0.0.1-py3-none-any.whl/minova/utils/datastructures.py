"""Utility data structures for headers, query params, and multi-dicts."""

from __future__ import annotations

import urllib.parse
from collections.abc import Iterator
from typing import Any


class Headers:
    """Immutable, case-insensitive HTTP headers backed by a raw ASGI list.

    Args:
        raw: List of ``[name_bytes, value_bytes]`` pairs (ASGI format).
    """

    def __init__(self, raw: list[list[bytes]] | list[tuple[bytes, bytes]]) -> None:
        self._list: list[tuple[bytes, bytes]] = [
            (k.lower(), v) for k, v in raw  # type: ignore[misc]
        ]

    def __getitem__(self, key: str) -> str:
        bkey = key.lower().encode("latin-1")
        for k, v in self._list:
            if k == bkey:
                return v.decode("latin-1")
        raise KeyError(key)

    def get(self, key: str, default: str | None = None) -> str | None:
        try:
            return self[key]
        except KeyError:
            return default

    def getlist(self, key: str) -> list[str]:
        bkey = key.lower().encode("latin-1")
        return [v.decode("latin-1") for k, v in self._list if k == bkey]

    def keys(self) -> list[str]:
        return [k.decode("latin-1") for k, _ in self._list]

    def values(self) -> list[str]:
        return [v.decode("latin-1") for _, v in self._list]

    def items(self) -> list[tuple[str, str]]:
        return [(k.decode("latin-1"), v.decode("latin-1")) for k, v in self._list]

    def __contains__(self, key: object) -> bool:
        if not isinstance(key, str):
            return False
        bkey = key.lower().encode("latin-1")
        return any(k == bkey for k, _ in self._list)

    def __iter__(self) -> Iterator[str]:
        for k, _ in self._list:
            yield k.decode("latin-1")

    def __len__(self) -> int:
        return len(self._list)

    def __repr__(self) -> str:
        return f"Headers({dict(self.items())!r})"

    @property
    def raw(self) -> list[tuple[bytes, bytes]]:
        return self._list


class MutableHeaders(Headers):
    """Mutable version of Headers for building responses."""

    def __init__(self, raw: list[list[bytes]] | list[tuple[bytes, bytes]] | None = None) -> None:
        super().__init__(raw or [])

    def set(self, key: str, value: str) -> None:
        bkey = key.lower().encode("latin-1")
        bval = value.encode("latin-1")
        for i, (k, _) in enumerate(self._list):
            if k == bkey:
                self._list[i] = (bkey, bval)
                return
        self._list.append((bkey, bval))

    def append(self, key: str, value: str) -> None:
        self._list.append((key.lower().encode("latin-1"), value.encode("latin-1")))

    def delete(self, key: str) -> None:
        bkey = key.lower().encode("latin-1")
        self._list = [(k, v) for k, v in self._list if k != bkey]

    def __setitem__(self, key: str, value: str) -> None:
        self.set(key, value)


class QueryParams:
    """Immutable query parameter mapping (supports multi-values).

    Args:
        query_string: Raw query string like ``"a=1&b=2&a=3"``.
    """

    def __init__(self, query_string: str) -> None:
        self._dict: dict[str, list[str]] = {}
        for key, value in urllib.parse.parse_qsl(query_string, keep_blank_values=True):
            self._dict.setdefault(key, []).append(value)

    def get(self, key: str, default: str | None = None) -> str | None:
        vals = self._dict.get(key)
        if vals:
            return vals[0]
        return default

    def getlist(self, key: str) -> list[str]:
        return self._dict.get(key, [])

    def __getitem__(self, key: str) -> str:
        try:
            return self._dict[key][0]
        except KeyError:
            raise KeyError(key) from None

    def __contains__(self, key: object) -> bool:
        return key in self._dict

    def __iter__(self) -> Iterator[str]:
        return iter(self._dict)

    def __len__(self) -> int:
        return len(self._dict)

    def items(self) -> list[tuple[str, str]]:
        return [(k, v[0]) for k, v in self._dict.items()]

    def multi_items(self) -> list[tuple[str, str]]:
        return [(k, v) for k, vals in self._dict.items() for v in vals]

    def keys(self) -> list[str]:
        return list(self._dict.keys())

    def __repr__(self) -> str:
        return f"QueryParams({self.items()!r})"


class ImmutableMultiDict:
    """Ordered multi-value dict (used for form data)."""

    def __init__(self, items: list[tuple[str, Any]]) -> None:
        self._items = list(items)

    def get(self, key: str, default: Any = None) -> Any:
        for k, v in self._items:
            if k == key:
                return v
        return default

    def getlist(self, key: str) -> list[Any]:
        return [v for k, v in self._items if k == key]

    def __getitem__(self, key: str) -> Any:
        for k, v in self._items:
            if k == key:
                return v
        raise KeyError(key)

    def __contains__(self, key: object) -> bool:
        return any(k == key for k, _ in self._items)

    def __iter__(self) -> Iterator[str]:
        seen: set[str] = set()
        for k, _ in self._items:
            if k not in seen:
                seen.add(k)
                yield k

    def items(self) -> list[tuple[str, Any]]:
        seen: set[str] = set()
        result = []
        for k, v in self._items:
            if k not in seen:
                seen.add(k)
                result.append((k, v))
        return result

    def multi_items(self) -> list[tuple[str, Any]]:
        return list(self._items)

    def __len__(self) -> int:
        return len({k for k, _ in self._items})

    def __repr__(self) -> str:
        return f"ImmutableMultiDict({self._items!r})"
